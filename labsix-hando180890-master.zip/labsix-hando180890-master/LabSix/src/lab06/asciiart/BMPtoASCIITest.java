package lab06.asciiart;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

public class BMPtoASCIITest {
	
	
	private BMPtoASCII b1;
	private String s1;
	
	@Before
	public void setUp() throws Exception {
		s1 = "/Users/handongbing/git/labsix-hando180890/LabSix/src/lab06/asciiart/images/monalisa";
		b1 = new BMPtoASCII (s1);
		b1.readFile();
	}

	@Test
	public void testHeight() throws IOException {
		assertEquals(547, b1.getHeight());
	}
  
	@Test
	public void testWidth() throws IOException {
		assertEquals(516, b1.getWidth());
	}

	@Test
	public void testValue() {
		assertEquals(69, b1.getIntensity(0, 0));
		assertEquals(72, b1.getIntensity(0, 515));
		assertEquals(85, b1.getIntensity(1, 0));
		assertEquals(82, b1.getIntensity(1, 515));
		assertEquals(107, b1.getIntensity(546, 0));
		assertEquals(106, b1.getIntensity(546, 515));
	}
}
