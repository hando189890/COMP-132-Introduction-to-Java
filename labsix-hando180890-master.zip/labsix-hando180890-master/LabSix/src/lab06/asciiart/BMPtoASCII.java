package lab06.asciiart;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;



/**
 * A class that can read pixel data for Windows Bitmap (BMP) image files and
 * write out a text file containing an ASCII art rendering of the image.
 * 
 * @author Grant Braught
 * @version Oct 26, 2016
 * 
 * @author Dongbing & Brain
 * @version 2019.4.1
 */  
public class BMPtoASCII {
	String filename;
	private int w;
	private int h;
	private int offset;
	private int[][] board;
	
	/**
	 * Create a new BMPtoASCII converter for the specified filename.
	 * 
	 * @param filename
	 *            the path to a file, but not containing the extension (i.e.
	 *            dir1/dir2/cat not dir1/dir2/cat.bmp).
	 */
	public BMPtoASCII(String filename) {
		 this.filename = filename;
		

	}

	/**
	 * Read the file specified in the constructor (adding a .bmp extension) into
	 * an array of intensity values (i.e. average the RGB values and store them
	 * into a 2d array of ints.)
	 */
	public void readFile() {
		DataInputStream dis = null;
		try {
			dis = new DataInputStream(new FileInputStream(filename+ ".bmp"));
			dis.skip(10);
			offset = Integer.reverseBytes(dis.readInt());
			dis.skip(4);
			w =Integer.reverseBytes(dis.readInt());
			h =Integer.reverseBytes(dis.readInt());
			dis.skip(offset-26);
			
			board = new int[h][w];
			for(int i=0; i<board.length; i++) {
				for(int j=0; j<board[i].length; j++) {
					int a = 0;
					int b = 0;
					int c = 0;
					try {
						a =dis.readUnsignedByte();
						}catch(IOException e) {
							System.out.println("Exception for IOException of R");
					}
					try {
					    b =dis.readUnsignedByte();
					}catch(IOException e) {
						System.out.println("Exception for IOException of G");
					}
						
					try {
					    c = dis.readUnsignedByte();
					}catch(IOException e) {
						System.out.println("Exception for IOException of B");
					}
					int v = (a+b+c)/3;
					board[i][j] = v;
				}
				dis.skip(board[i].length % 3);
			}
		         
			
		} catch (FileNotFoundException e) {
			System.out.println("Unable to open file: " + filename);
		} catch (IOException e) {
			System.out.println("Error reading file: " + filename);
		} finally {
			if (dis != null) {
				try {
					dis.close();
				} catch (IOException e) {
					System.out.println("Error closing file: " + filename);
				}
			}
		}
	}

	/**
	 * Get the width of the image, or -1 if the file has not yet been read.
	 * 
	 * @return the width of the image or -1.
	 * @throws IOException 
	 */
	public int getWidth() throws IOException {
		//DataInputStream dis = null;
		try {
			//dis = new DataInputStream(new FileInputStream(filename+ ".bmp"));
			//dis.skip(18);		
			//int imgWidth = Integer.reverseBytes(dis.readInt());
			//int imgWidth = dis.readInt();
			//return imgWidth;
			this.readFile();
			return w;
		}catch (Exception e){
			return -1;
		}
	}

	/**
	 * Get the height of the image or -1 if the file has not yet been read.
	 * 
	 * @return the height of the image or -1.
	 * @throws IOException 
	 */
	public int getHeight() throws IOException {
		//DataInputStream dis = null;
		try {
			//dis = new DataInputStream(new FileInputStream(filename+ ".bmp"));
			//System.out.print("i'm here!");
			//dis.skip(22);
			//int imgHeight = Integer.reverseBytes(dis.readInt());
			//int imgHeight = dis.readInt();
			//return imgHeight;
			this.readFile();
			return h;
		}catch (Exception e){
			return -1;
		}
	}

	/**
	 * Get the intensity (average of the RGB values) of the pixel at row, col in
	 * the .bmp file.
	 * 
	 * @param row
	 *            the row of the pixel
	 * @param col
	 *            the column of the pixel
	 * @return the intensity of the pixel at row, col, or -1 if the file has not
	 *         been read.
	 */
	public int getIntensity(int row, int col) {
		//DataInputStream dis = null;
		try {
			//dis = new DataInputStream(new FileInputStream(filename+ ".bmp"));
			this.readFile();
			return board[row][col];
		}catch(Exception e) {
			System.out.println("File not found exception for intensity");
			return -1;
			
		}
	}

	/**
	 * Write the ASCII art rendering of the .bmp file into a text file using the
	 * name specified in the constructor (adding a .txt extension).
	 */
	public void writeFile() {
		//DataOutputStream dos = null;
		PrintWriter pw = null;
		
		try {
			String newFilename = filename + ".text";
			//dos = new DataOutputStream(new FileOutputStream(newFilename, false));
			pw = new PrintWriter(new FileOutputStream(filename, false));
			
			for(int i= board.length-1; i >= 0; i--) {
		//	for (int i = 0; i < board.length; i++) {	
				for(int j=0; j < board[i].length; j++) {
					int current = board[i][j];
					if (current >= 0 & current <= 31) {
						//dos.writeUTF(" ");
						pw.print(" ");
					} else if (current >= 32 & current <= 63) {
						//dos.writeUTF(".");
						pw.print(".");
					}else if (current >= 64 & current <= 95) {
						//dos.writeUTF(",");
						pw.print(",");
					}else if(current >= 96 & current <= 127) {
						//dos.writeUTF(":");
						pw.print(":");
					}else if (current >= 128 & current <= 159) {
						//dos.writeUTF("o");
						pw.print("o");
					}else if (current >= 160 & current <= 191) {
						//dos.writeUTF("O");
						pw.print("O");
					}else if (current >= 192 & current <= 223) {
						//dos.writeUTF("0");
						pw.print("0");
					}else if (current >= 224 & current <= 255) {
						//ßdos.writeUTF("@");
						pw.print("@");
					}
						
					
					}
				pw.println();
				}
		
		} catch (FileNotFoundException e) {
			System.out.println("Unable to open file: " + filename);
		} catch (IOException e) {
			System.out.println("Error writing to file: " + filename);
		} finally {
			if ( pw != null) {
				pw.close();
			}
//				try {
					//dos.close();
					
//				} catch (IOException e) {
//					System.out.println("Error closing file: " + filename);
//				}
//			}
//     	}
	}
}
	



public static void main(String[] args) {
	String filename = "/Users/handongbing/git/labsix-hando180890/LabSix/src/lab06/asciiart/images/monalisa";
    BMPtoASCII bmp = new BMPtoASCII(filename);
    bmp.readFile();
    bmp.writeFile();  
  } 
}
