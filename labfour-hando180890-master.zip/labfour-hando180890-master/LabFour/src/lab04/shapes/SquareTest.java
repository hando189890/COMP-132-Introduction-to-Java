package lab04.shapes;

import static org.junit.Assert.*;

import org.junit.Test;

public class SquareTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
