package lab04.shapes;

import java.awt.Color;

/**
 * This class draw a line with specific direction and length
 * The line can move and translate to some where else
 * @author Dongbing & Katya 
 * @version 2019.3.4
 * 
 */

public class Line extends Point{

private int endX;
private int endY;

public Line (int x, int y, Color c, int initendX, int initendY) {
	 super(x, y, c);
	 endX = initendX;
	 endY = initendY; 
 }

/**
 * Get the x coordination of end point
 * @return endX
 */

 public int getEndX() {
	 return endX;
 }
 
 /**
  * Get the y coordination of the end point
  * @return endY
  */
 public int getEndY() {
	 return endY;
 }
 
 /**
  * Move the line to new position
  * @param newX
  * @param newY
  * @param newEndX
  * @param newEndY
  */
 public void move(int newX, int newY, int newEndX, int newEndY ) {
	super.move(newX, newY);
	endX = newEndX;
	endY = newEndY;
 }
 
 
 /**
  *  /**
     * Move the Point relative to its current location. The location of the
     * point is moved by adding the parameters to the Point's current
     * location.
     * 
     * @param deltaX the change in the x coordinate. Positive values move the
     *            Point to the right, negative values move it to the left.
     * @param deltaY the change in the y coordinate. Positive values move the
     *            Point down, negative values move it up.
     *
     * @param deltaX
     * @param deltaY
     */
 public void translate (int deltaX, int deltaY) {
	 super.translate(deltaX, deltaY);
	 endX = endX + deltaX;
	 endY = endY + deltaY;
 }
 

}
