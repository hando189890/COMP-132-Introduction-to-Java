package lab04.shapes;
import java.awt.Color;
import java.awt.Graphics;

/**
 * create a ellipse on the screen
 * this ellipse has initial information and can be move and translate
 * 
 * @author Dongbing
 * @version 2019.3.4
 *
 */
public class Ellipse extends Point implements Scaleable {
	private int longRadius;
	private int shortRadius;

	/**
	 * create a ellipse class by calling the super class and also 
	 * set the initial long and short radius value
	 * @param x
	 * @param y
	 * @param c
	 * @param longRadius
	 * @param shortRadius
	 */
	public Ellipse(int x, int y, Color c, int longRadius, int shortRadius) {
		super(x, y, c);
		this.longRadius = longRadius;
		this.shortRadius = shortRadius;
	}
	
	/**
	 * return the length of long radius
	 * @return longRadius
	 */
	public int getLongRadius() {
		return longRadius;	
	}
	
	
	/**
	 * return the length of short radius  
	 * @return shortRadius
	 */
	public int getShortRadius() {
		return shortRadius;
	}

	 // === Implementation of the Drawable interface ===

    /**
     * Draw this DrawableCircle onto the specified Graphics object.
     * 
     * @param g the Graphics object on which to draw this DrawableCircle.
     */
    public void draw(Graphics g) {
        g.setColor(super.getColor());
        g.fillOval(super.getX() - longRadius, super.getY() - shortRadius, 2*longRadius, 2*shortRadius);
    }
	
    
    
    // === Implementation of the Scaleable interface ===
    /**
     * Scale this Circle by the specified factor. For example a factor of 2.0
     * will make the radius twice as bit and a factor of 0.5 will make it half
     * as large. If the factor is negative the radius is not changed.
     * 
     * @param factor the factor by which this Circle is to be scaled.
     */
    public void scale(double factor) {
        if (factor > 0) {
            longRadius = (int) (Math.round(longRadius * factor));
            shortRadius = (int) (Math.round(shortRadius * factor));
        }
    }
	
	
}
