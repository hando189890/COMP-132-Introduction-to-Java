package lab04.shapes;

import java.awt.Color;


/**
 * Create a circle by using the super eclipse class
 * @author Dongbing & Katya
 * @version 2019.3.4
 */

public class Circle extends Ellipse{

	
	/**
	 * create a new circle by calling the super class
	 * @param x
	 * @param y
	 * @param c
	 * @param initR
	 */
	public Circle(int x, int y, Color c, int initR) {
		super(x, y, c, initR, initR);
	}

}
