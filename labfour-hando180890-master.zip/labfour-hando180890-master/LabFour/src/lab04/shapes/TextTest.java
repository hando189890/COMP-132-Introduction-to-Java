package lab04.shapes;

import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Before;
import org.junit.Test;

public class TextTest {
	
	
	private Text t1;
	
	@Before
    public void setUp() throws Exception {
	 t1 = new Text(0, 5, Color.black, "test" );
 }

	@Test
	public void testReturnTest() {
		assertEquals("test", t1.getText());
	}

}
