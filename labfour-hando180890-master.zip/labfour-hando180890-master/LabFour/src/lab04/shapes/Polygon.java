package lab04.shapes;
import java.awt.Color;
import java.awt.Graphics;

/**
 * Bonus Question
 * create a polygon and draw it on the screen
 * set inital information here
 * @author Dongbing & Katya
 * @version 2019.3.4
 *
 */

public class Polygon extends Point {
          private int num;
          private int[] xp;
          private int[] yp;
          
          
/**
 * create a polygon by calling the super class and set initial points and color
 * @param xp array of initial x points
 * @param yp array of initial y points
 * @param c
 * @param num number of points of this polygon
 */
	public Polygon(int[] xp, int[] yp, Color c, int num) {
		super(xp[0], yp[0], c);
		this.xp = xp;
		this.yp = yp;
		this.num = num;
	
	}
/**
 * return number of points
 * @return num
 */
	public int getNumberOfPoints() {
		return num;
	}
/**
 * return specific x points
 * @param a
 * @return xp[a]
 */
	public int getXpoint(int a) {
		return xp[a];
	}
/**
 * return specific y points
 * @param b
 * @return yp[b]
 */
	public int getYpoint(int b) {
		return yp[b];
	}
	
/**
  * Move the picture relative to its current location. The location of the
  * point is moved by adding the parameters to the Point's current
  * location.
  * 
  * @param deltaX the change in the x coordinate. Positive values move the
  *            Point to the right, negative values move it to the left.
  * @param deltaY the change in the y coordinate. Positive values move the
  *            Point down, negative values move it up.
  *
  * @param deltaX
  * @param deltaY
  */
	
	public void translate (int deltaX, int deltaY) {
		 super.translate(deltaX, deltaY);
		 for (int index = 1; index <= num-1; index++) {
			 xp[index] = xp[index] + deltaX;
			 yp[index] = yp[index] + deltaY;
		 }
	}
	
/**
 * move a specific points to new location
 * @param newX
 * @param newY
 * @param newNum
 */
	public void move(int newX, int newY, int newNum) {
	xp[newNum] = newX;
	yp[newNum] = newY;
	
  }
	
	// === Implementation of the Drawable interface ===

    /**
     * Draw this picture onto the specified Graphics object.
     * 
     * @param g the Graphics object on which to draw this DrawableCircle.
     */
    public void draw(Graphics g) {
        g.setColor(getColor());
        g.fillPolygon(xp, yp, num);
    }



}
 
	


