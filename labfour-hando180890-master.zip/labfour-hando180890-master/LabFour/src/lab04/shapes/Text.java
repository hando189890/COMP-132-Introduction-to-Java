package lab04.shapes;
import java.awt.Color;


import java.awt.Graphics;

/**
 * Create a class which can draw a text with initial position and color
 * @author Dongbing & Katya
 * @version 2019.3.4
 */


public class Text extends Point {
	private String text;
	
	/**
	 * Create a class by calling the super point class and set initial information
	 * @param x
	 * @param y
	 * @param c
	 * @param text
	 */
	public Text (int x, int y, Color c, String text) {
		super (x, y, c);
		this.text = text;
		
	}
	
	
	/**
	 * Get the information of text
	 * @return test
	 */
	public String getText() {
		return text;
	}
	
	/**
     * Draw this DrawableCircle onto the specified Graphics object.
     * 
     * @param g the Graphics object on which to draw this DrawableCircle.
     */
    public void draw(Graphics g) {
    	Color theColor = super.getColor();
    	int x = super.getX();
    	int y = super.getX();
        g.setColor(theColor);
        g.drawString(text, x, y);
    }
    
    
    
    
    
}


	


