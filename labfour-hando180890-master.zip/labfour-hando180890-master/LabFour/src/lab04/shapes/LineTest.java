package lab04.shapes;

import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Before;
import org.junit.Test;

public class LineTest {
	
  private Line l1;
	
  @Before
	    public void setUp() throws Exception {
		 l1 = new Line(0, 5, Color.black, 4, 5 );
	 }

	@Test
	public void testEndX() {
		assertEquals(4, l1.getEndX());
		
	}
	
	@Test
	public void testEndY() {
		assertEquals(5, l1.getEndY());
	}
	
	@Test
	public void testMove() {
		l1.move(1, 0, 1, 4);
		assertEquals(1, l1.getX());
		assertEquals(0, l1.getY());
		assertEquals(1, l1.getEndX());
		assertEquals(4, l1.getEndY());
	}
	
	@Test
	public void testTranslation() {
		l1.translate(2, -1);
		assertEquals(2, l1.getX());
		assertEquals(6, l1.getEndX());
		assertEquals(4, l1.getY());
		assertEquals(4, l1.getEndY());
	}

}
