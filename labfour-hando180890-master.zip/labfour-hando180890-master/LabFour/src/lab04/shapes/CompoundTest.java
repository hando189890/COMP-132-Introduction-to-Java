package lab04.shapes;

import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Before;
import org.junit.Test;

public class CompoundTest {

private Compound c1;
	
	@Before
    public void setUp() throws Exception {
	 c1 = new Compound(1, 2, Color.red, 3, 4, Color.blue, 5, 6, 7, Color.black, 8);
 }
	
	
	@Test
	public void testConstrcutor() {
		assertEquals(3, c1.getXOfSquare());
		assertEquals(4, c1.getYOfSquare());
		assertEquals(5, c1.getSideOfSquare());
		assertEquals(6, c1.getXOfCircle());
		assertEquals(7, c1.getYOfCircle());
		assertEquals(8, c1.getRadiusOfCircle());
		assertEquals(Color.blue, c1.getColorOfSquare());
		assertEquals(Color.black, c1.getColorOfCirlce());
	}

	
	@Test
	public void testMove() {
		c1.move(3, 4, 13, 14, 23, 24);
		assertEquals(13, c1.getXOfSquare());
		assertEquals(14, c1.getYOfSquare());
		assertEquals(23, c1.getXOfCircle());
		assertEquals(24, c1.getYOfCircle());
	}
	
	@Test
	public void testTranslation() {
		c1.translate(10, 10);
		assertEquals(13, c1.getXOfSquare());
		assertEquals(14, c1.getYOfSquare());
		assertEquals(16, c1.getXOfCircle());
		assertEquals(17, c1.getYOfCircle());
		
	}
}
