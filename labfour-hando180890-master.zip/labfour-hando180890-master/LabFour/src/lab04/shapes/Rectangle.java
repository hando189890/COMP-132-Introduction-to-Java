package lab04.shapes;

import java.awt.Color;


/**
 * Create a rectangle on the screen with initial information.
 * This is a subclass of the Point and also has Scale interface
 * @author Dongbing & Katya
 * @version 2019.3.4
 */
import java.awt.Graphics;

public class Rectangle extends Point implements Scaleable{
	
	private int l;
	private int s; 
	

	/**
     * Construct a rectangle with initial long and short side and color
     * the x, y coordinates represent the upper left corner of the the square
     *  which is its location
     * 
     * @param initL the long side
     * @param initS the short side
     * @param c the color .
     * @param x the x coordinates
     * @param y the y coordinates
     */
    public Rectangle(int x, int y, Color c, int initL, int initS) {
    	super(x, y, c);
    	l = initL;
    	s = initS;
    }
   
    /**
     * Get the length of the long side
     * @return l
     */
    public int getLongSide() {
    	return l;
    }
    
    /**
     * Get the length of the short side
     * @return s
     */
    public int getShortSide() {
    	return s;
    }
    
    
    // === Implementation of the Scaleable interface ===
    /**
     * Scale this rectangle by the specified factor. For example a factor of 2.0
     * will make the radius twice as bit and a factor of 0.5 will make it half
     * as large. If the factor is negative the radius is not changed.
     * 
     * @param factor the factor by which this rectangle is to be scaled.
     */
    public void scale(double factor) {
        if (factor > 0) {
            l = (int) (Math.round(l * factor));
            s = (int) (Math.round(s * factor));
        }
    }
    
    
 // === Implementation of the Drawable interface ===

    /**
     * Draw this picture onto the specified Graphics object.
     * 
     * @param g the Graphics object on which to draw this DrawableCircle.
     */
    public void draw(Graphics g) {
        g.setColor(getColor());
        int x = super.getX();
        int y = super.getY();
        g.fillRect(x, y, l, s);
    }

    
    
}
