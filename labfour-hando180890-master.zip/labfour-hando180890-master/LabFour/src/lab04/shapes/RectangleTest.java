package lab04.shapes;

import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Before;
import org.junit.Test;

public class RectangleTest {

	
	private Rectangle r1;
	
	@Before
    public void setUp() throws Exception {
	 r1 = new Rectangle(0, 5, Color.black, 5, 4 );
 }
	
	@Test
	public void testReturnInformation() {
		assertEquals(5, r1.getLongSide());
		assertEquals(4, r1.getShortSide());
	}

	@Test
    public void testScale() {
        r1.scale(2.0);
        assertEquals(10, r1.getLongSide());
		assertEquals(8, r1.getShortSide());
        
        r1.scale(0.5);
        assertEquals(5, r1.getLongSide());
		assertEquals(4, r1.getShortSide());
		
        r1.scale(-2.0);
        assertEquals(5, r1.getLongSide());
		assertEquals(4, r1.getShortSide());
    }
	
}
