package lab04.shapes;

import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Before;
import org.junit.Test;

public class PolygonTest {
	private Polygon p1;
	private int[] xp;
	private int[] yp;
	
	@Before
    public void setUp() throws Exception {
      xp = new int[5];     
      yp = new int[5];
      xp[0] = 0;
      yp[0] = 0;
      xp[1] = 20;
      yp[1] = 10;
      xp[2] = 15;
      yp[2] = 30;
      xp[3] = 10;
      yp[3] = 40;
      xp[4] = 5;
      yp[4] = 15;
		
	 p1 = new Polygon(xp, yp, Color.black, 5);
 }

	@Test
	public void testConstructor() {
		assertEquals(5, p1.getNumberOfPoints());
		assertEquals(20, p1.getXpoint(1));
		assertEquals(10, p1.getYpoint(1));
		assertEquals(15, p1.getXpoint(2));
		assertEquals(30, p1.getYpoint(2));
		assertEquals(10, p1.getXpoint(3));
		assertEquals(40, p1.getYpoint(3));
		assertEquals(5, p1.getXpoint(4));
		assertEquals(15, p1.getYpoint(4));
	}
	
	@Test
	public void testTranslation() {
		p1.translate(10, 20);
		assertEquals(5, p1.getNumberOfPoints());
		assertEquals(30, p1.getXpoint(1));
		assertEquals(30, p1.getYpoint(1));
		assertEquals(25, p1.getXpoint(2));
		assertEquals(50, p1.getYpoint(2));
		assertEquals(20, p1.getXpoint(3));
		assertEquals(60, p1.getYpoint(3));
		assertEquals(15, p1.getXpoint(4));
		assertEquals(35, p1.getYpoint(4));
	}
	
	@Test
	public void testMove() {
		p1.move(1, 2, 3);
		assertEquals(1, p1.getXpoint(3));
		assertEquals(2, p1.getYpoint(3));
	}

}
