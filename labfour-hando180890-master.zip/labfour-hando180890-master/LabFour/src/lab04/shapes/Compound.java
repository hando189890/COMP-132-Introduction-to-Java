package lab04.shapes;

import java.awt.Color;
import java.awt.Graphics;

/**
 * This is a bonus question to draw a compound picture with a point, square, and a circle
 * The creation a this class is by using the feature of other and the super class;
 * @author Dongbing & Katya
 * @version 2019.3.5
 *
 */

public class Compound extends Point {
	private int xs;
	private int ys;
	private int s;
	private int xr;
	private int yr;
	private int r;
    private Color cs;
    private Color cr;
    private Color c;
    
    /**
     * Create a picture which has a point, a square and a circle
     * @param x x coordination of point
     * @param y y coordination of point
     * @param c color of point
     * @param xs x coordination of square
     * @param ys y coordination of square
     * @param cs color of square
     * @param initS the side of square
     * @param xr x coordination of circle
     * @param yr y coordination of circle
     * @param cr color of circle
     * @param initR the radius of circle
     */
    
	public Compound(int x, int y, Color c, int xs, int ys, Color cs, int initS, int xr, int yr, Color cr, int initR ) {
		super(x, y, c);
		this.xs = xs;
		this.ys = ys;
		this.s = initS;
		this.xr = xr;
		this.yr = yr;
		this.r = initR;
		this.cs = cs;
		this.cr = cr;
		this.c = c;
		  
	}
	
	/**
	 * Get the x coordinates of square
	 * @return xs
	 */
	
	public int getXOfSquare() {
		return xs;
	}
	
	/**
	 * get the y coordinates of square
	 * @return ys
	 */
	public int getYOfSquare() {
		return ys;
	}

	/**
	 * get the side of square
	 * @return s
	 */
	public int getSideOfSquare() {
		return s;
	}
	
	/**
	 * get the x coordinates of circle
	 * @return xr
	 */

	public int getXOfCircle() {
		return xr;
	}
	
	/**
	 * get the y coordinates of circle
	 * @return yr
	 */

	public int getYOfCircle() {
		return yr;
	}
	
	/**
	 * get the radius of circle
	 * @return r
	 */
	public int getRadiusOfCircle() {
		return r;
	}

	/**
	 * get the color of square
	 * @return cs
	 */
	public Color getColorOfSquare() {
		return cs;
	}
	
	/**
	 * get the color of cirlce
	 * @return cr
	 */
	public Color getColorOfCirlce() {
		return cr;
	}
	
	 /**
	  * Move the picture to a new location. This method changes the location
      * of the point to the values provided by the parameters.
	  * @param newX x for point
	  * @param newY y for point
	  * @param newXS x for square
	  * @param newYS y for square
	  * @param newXR x for circle
	  * @param newYR y for circle
	  */
    public void move(int newX, int newY, int newXS, int newYS, int newXR, int newYR) {
        super.move(newX, newY);
        xs = newXS;
        ys = newYS;
        xr = newXR;
        yr = newYR;
        
    }

    /**
     * /**
     * Move the picture relative to its current location. The location of the
     * picture is moved by adding the parameters to the Point's current
     * location.
     * 
     * @param deltaX the change in the x coordinate. Positive values move the
     *            Point to the right, negative values move it to the left.
     * @param deltaY the change in the y coordinate. Positive values move the
     *            Point down, negative values move it up.
     * @param deltaXS 
     * @param deltaYS
     * @param deltaXR
     * @param deltaYR
     */
    public void translate(int deltaX, int deltaY) {
        xs = xs + deltaX;
        ys = ys + deltaY;
        xr = xr + deltaX;
        yr = yr + deltaY;
    }
    
    /**
     * Draw the Point on the graphics context.
     * 
     * @param g the Graphics context on which to draw the Point.
     */
    public void draw(Graphics g) {
        super.draw(g);
        g.setColor(cs);
        g.fillRect(xs, ys, s, s);
        g.setColor(cr);
        g.fillOval(xr, yr, r, r);
        
    }
        


}
