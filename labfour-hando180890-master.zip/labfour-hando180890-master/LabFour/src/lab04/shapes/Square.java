package lab04.shapes;

import java.awt.Color;

/**
 * Create a square by calling the super class Rectangle
 * @author Dongbing & Katya
 * @version 2019.3.4
 *
 */

public class Square extends Rectangle {

	public Square(int x, int y, Color c, int initS) {
		super(x, y, c, initS, initS);
	}

}
