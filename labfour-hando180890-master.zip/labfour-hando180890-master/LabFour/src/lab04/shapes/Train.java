package lab04.shapes;

import java.awt.Color;

import lab04.shapes.Circle;
import lab04.shapes.DrawableObjectList;
import lab04.shapes.DrawingTablet;
import lab04.shapes.Rectangle;

public class Train {

	/**
	 * This class is try to draw a simple train with simple pictures that i have create in the lab
	 * assignment. Basically, the train is consist of square and circle. 
	 * @author Dongbing & Katya
	 * @version 2019.2.16
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 /*
         * Create a DrawableObject list and use it to create a DrawingTablet.
         */
        DrawableObjectList objList = new DrawableObjectList();
        DrawingTablet tablet = new DrawingTablet("Train", 200, 200, objList);
        
        int[] xp = new int[5];     
        int[] yp = new int[5];
        xp[0] = 140;
        yp[0] = 0;
        xp[1] = 180;
        yp[1] = 0;
        xp[2] = 200;
        yp[2] = 30;
        xp[3] = 160;
        yp[3] = 55;
        xp[4] = 120;
        yp[4] = 30;

        // Create pictures on screen.
        Circle sun = new Circle(15, 15, Color.red, 10);
        Circle w1 = new Circle(20, 190, Color.black, 10);
        Circle w2 = new Circle(50, 190, Color.black, 10);
        Circle w3 = new Circle(76, 190, Color.black, 10);
        Circle w4 = new Circle(106, 190, Color.black, 10);
        Circle w5 = new Circle(132, 190, Color.black, 10);
        Circle w6 = new Circle(162, 190, Color.black, 10);
        Circle ww1 = new Circle(20, 100, Color.white, 8);
        Circle ww2 = new Circle(30, 80, Color.white, 5);
        Ellipse e1 = new Ellipse(80, 20, Color.white, 30, 15);
        Rectangle s1 = new Rectangle(7, 145, Color.green, 56, 40);
        Rectangle s2 = new Rectangle(63, 145, Color.red, 56, 40); 
        Rectangle s3 = new Rectangle(119, 145, Color.green, 56, 40);
        Square s4 = new Square(7, 120, Color.black, 25);
        Polygon p1 = new Polygon(xp, yp, Color.green, 5);
        Line l1 = new Line(140, 60, Color.red, 140, 70);
        Text t1 = new Text(130, 50, Color.black, "Train"); 
        
        objList.addDrawable(sun);
        objList.addDrawable(w1);
        objList.addDrawable(w2);
        objList.addDrawable(w3);
        objList.addDrawable(w4);
        objList.addDrawable(w5);
        objList.addDrawable(w6);
        objList.addDrawable(ww1);
        objList.addDrawable(ww2);
        objList.addDrawable(s1);
        objList.addDrawable(s2);
        objList.addDrawable(s3);
        objList.addDrawable(s4);
        objList.addDrawable(l1);
        objList.addDrawable(t1);
        objList.addDrawable(e1);
        objList.addDrawable(p1);
        
        tablet.repaint();
	}


}
