package lab04.shapes;

import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Before;
import org.junit.Test;

public class EllipseTest {
	
	
	private Ellipse e1;
	
	@Before
    public void setUp() throws Exception {
	 e1 = new Ellipse(0, 5, Color.black, 5, 4 );
 }

	@Test
	public void testReturnInformation() {
		assertEquals(5, e1.getLongRadius());
		assertEquals(4, e1.getShortRadius());
	}

	@Test
    public void testScale() {
        e1.scale(2.0);
        assertEquals(10, e1.getLongRadius());
		assertEquals(8, e1.getShortRadius());
        
        e1.scale(0.5);
        assertEquals(5, e1.getLongRadius());
		assertEquals(4, e1.getShortRadius());
		
        e1.scale(-2.0);
        assertEquals(5, e1.getLongRadius());
		assertEquals(4, e1.getShortRadius());
    }

}
