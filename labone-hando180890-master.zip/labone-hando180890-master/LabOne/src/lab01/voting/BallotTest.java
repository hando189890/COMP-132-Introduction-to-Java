package lab01.voting;
	
	import static org.junit.Assert.*;
	
	import org.junit.Before;
	import org.junit.Test;
	
	public class BallotTest {
	
		private Ballot b1; 
		private Candidate c1;
		private Candidate c2;
		private Candidate c3;
		private Candidate c4;
		
	
	    @Before
	    public void setUp() throws Exception {
	        /*
	         * Construct all of the objects being used in the test fixture here.
	         */
	        b1 = new Ballot("Ballot1");
	        c1 = new Candidate("candidate1", Candidate.DEMOCRAT, 20);
	        c2 = new Candidate("candidate2", Candidate.REPUBLICAN, 30);
	        c3 = new Candidate("candidate3", Candidate.INDEPENDENT, 40);
	        c4 = new Candidate("candidate4", Candidate.DEMOCRAT, 50);
	    } 
	
		@Test
		public void testConstructor() {
			assertEquals("Ballot1", b1.getElection());
			assertEquals(0, b1.getNumCandidates());
		}
		
		@Test
		public void testAddCandidate() {
			assertEquals(0, b1.getNumCandidates());
			b1.addCandidate(c1);
			assertEquals("Ballot1", b1.getElection());
			assertEquals(1, b1.getNumCandidates());
		}
		
		@Test
		public void testNotHaveName() {
			b1.addCandidate(c1);
			assertNull(b1.getCandidate("candidate5"));
		}
		
		@Test
		public void testHaveName() {
			b1.addCandidate(c1);
			b1.addCandidate(c2);
			b1.addCandidate(c3);
			assertNotNull(b1.getCandidate("candidate2"));
			Candidate c4 = b1.getCandidate("candidate2");
			assertEquals("candidate2", c4.getName());
			assertEquals("Republican", c4.getParty());
		}
		
		
		@Test
		public void testVoteTrue() {
			b1.addCandidate(c1);
			b1.addCandidate(c2);
			b1.addCandidate(c3);
			b1.voteForCandidate("candidate2");
			Candidate c4 = b1.getCandidate("candidate2");
			assertEquals("candidate2", c4.getName());
			assertEquals("Republican", c4.getParty());
			assertEquals(31, c4.getVotes());
		}
		
		@Test
		public void testVoteFalse() {
			b1.addCandidate(c1);
			b1.addCandidate(c2);
			b1.addCandidate(c3);
			b1.voteForCandidate("candidate5");
		}
	
		@Test
		public void testVoteStraightTrue() {
			b1.addCandidate(c1);
			b1.addCandidate(c2);
			b1.addCandidate(c3);
			b1.addCandidate(c4);
			b1.voteStraightTicket("Democrat");
			Candidate c5 = b1.getCandidate("candidate1");
			assertEquals("Democrat", c5.getParty());
			assertEquals(21, c5.getVotes());
			Candidate c6 = b1.getCandidate("candidate4");
			assertEquals("Democrat", c6.getParty());
			assertEquals(51, c6.getVotes());
			Candidate c7 = b1.getCandidate("candidate2");
			assertEquals(30, c7.getVotes());
			Candidate c8 = b1.getCandidate("candidate3");
			assertEquals(40, c8.getVotes());							
		}
		
		@Test
		public void testVoteStraightFalse() {
			b1.addCandidate(c1);
			b1.addCandidate(c2);
			b1.addCandidate(c4);
			b1.voteStraightTicket("independent");
		}
		
		@Test
		public void testGetCandidateInformation() {
			b1.addCandidate(c1);
			b1.addCandidate(c2);
			b1.addCandidate(c4);
			b1.getCandidatesInformation();;
		}
		
		@Test
		public void testWinnerTrue() {
			b1.addCandidate(c1);
			b1.addCandidate(c2);
			b1.addCandidate(c3);
			Candidate c5 = b1.getWinner();
			assertEquals("Independent", c5.getParty());
			assertEquals(40, c5.getVotes());
		
	}
		
		@Test
		public void testWinnerFalse(){
			b1.getWinner();
		
	}
}
