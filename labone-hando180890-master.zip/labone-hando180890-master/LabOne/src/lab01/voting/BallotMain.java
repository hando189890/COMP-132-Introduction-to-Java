package lab01.voting;

import java.util.Scanner;

/**
 * this main method process every command line in java to
 * finish lab assignment requirement
 *
 * @author Dongbing & Dongru
 * @author Dickinson College
 * @version 2019.1.26
 */
public class BallotMain {

    /**
     * process and print out all the requirement followed by the number and value
     * of each of the command line arguments that were provided
     * to the program.
     * 
     * @param args the command line arguments.
     */
    public static void main(String[] args) {
       Scanner s = new Scanner(System.in);
       Ballot b1 = new Ballot("ballot1");
       Candidate c1 = new Candidate("candidate1", Candidate.DEMOCRAT, 20);
       Candidate c2 = new Candidate("candidate2", Candidate.REPUBLICAN, 30);
       Candidate c3 = new Candidate("candidate3", Candidate.INDEPENDENT, 40);
       Candidate c4 = new Candidate("candidate4", Candidate.DEMOCRAT, 50);
       Candidate c5 = new Candidate("candidate4", Candidate.DEMOCRAT, 60);
       b1.addCandidate(c1);
       b1.addCandidate(c2);
       b1.addCandidate(c3);
       b1.addCandidate(c4);
       b1.addCandidate(c5);
       b1.getCandidatesInformation();
       
       if (s.hasNext()) {
    	   String str1 = s.next();
    	   if (str1.equals("Quit")) {
    	   s.close();
         }
       }
       
       b1.voteForCandidate("candidate1");
       b1.voteStraightTicket("Democrat");
       b1.getWinner();
       
    }
       
   }