package lab01.voting;

import static org.junit.Assert.*;
import org.junit.*;

public class CandidateTest {

    /*
     * Candidate for the test fixture. This variable is a field and is thus
     * available in all of the tests.
     */
    private Candidate c1;
    private Candidate c2;
    private Candidate c3;
    
    @Before
    public void setUp() throws Exception {
        /*
         * Construct all of the objects being used in the test fixture here.
         */
        c1 = new Candidate("Joe", Candidate.DEMOCRAT);
        c2 = new Candidate("Bob", Candidate.REPUBLICAN);
        c3 = new Candidate("Zore", Candidate.REPUBLICAN);
    }

    @Test
    public void testTwoArgConstructor() {
        assertEquals("Joe", c1.getName());
        assertEquals(Candidate.DEMOCRAT, c1.getParty());
        assertEquals(0, c1.getVotes());
    }

    @Test
    public void testThreeArgConstructor() {
        Candidate c4 = new Candidate("Joe", Candidate.DEMOCRAT, 10);
        assertEquals("Joe", c4.getName());
        assertEquals(Candidate.DEMOCRAT, c4.getParty());
        assertEquals(10, c4.getVotes());
    }

    @Test
    public void testSetParty() {
        c1.setParty(Candidate.INDEPENDENT);
        assertEquals(Candidate.INDEPENDENT, c1.getParty());
    }

    @Test
    public void testIncreaseVotesNoArgs() {
        c1.increaseVotes();
        assertEquals(1, c1.getVotes());
        c1.increaseVotes();
        assertEquals(2, c1.getVotes());
    }
    
    @Test
    public void testIncreaseVotesOneArg() {
        c1.increaseVotes(5);
        assertEquals(5, c1.getVotes());
        c1.increaseVotes(10);
        assertEquals(15, c1.getVotes());
    }
    
    @Test
    public void testDefeatedTrue() {
    	c1.increaseVotes(5);	
    	assertTrue(c1.defeated(c2));
    }
    
    @Test
    public void testDefeatedFalse() {
    	c2.increaseVotes(5);	
    	assertFalse(c1.defeated(c2));
    }
    
    @Test
    public void testDefeatedTie() {	
    	assertFalse(c1.defeated(c2));
    }
    
    @Test
    public void testSamePartyT() {	
    	assertSame(c2.getParty(), c3.getParty());
    }
    
    @Test
    public void testSamePartyF() {	
    	assertNotSame(c1.getParty(), c2.getParty());
    }
     
    
}