package lab01.voting;
	import java.util.ArrayList;
	
	/**
	 * Representation of a candidate running for office.
	 *
	 
	 * @author Dickinson College 
	 * 
	 * @author (Dongbing & Dongru)
	 * @version (2019.1.23)
	 */
	
	public class Ballot {
		private String ballotName;
		private ArrayList<Candidate> candidateList;
	/**
	 * construct the ballot class with class name
	 * @param name the class name
	 */
		public Ballot(String name) {
	 
			ballotName = name;
			candidateList = new ArrayList<Candidate>();
		}
	/**
	 *get the election name
	 *@return ballotName
	 */
	
		public String getElection() {
			return ballotName;
		}
	
	/**
	 * get the number of candidates in this election
	 * @return number of candidates in this election
	 */
		public int getNumCandidates() {
			return candidateList.size();
		}
	/**
	 * add a new candidate in the collection
	 * @param newCandidate
	 */
		public void addCandidate(Candidate newCandidate) {
			candidateList.add(newCandidate);
		}
		
	/**
	 * find candidate by specific name
	 * @param name
	 * @return the candidate
	 */
	
		public Candidate getCandidate(String name) {
			for(int i = 0; i < candidateList.size(); i++) {
				Candidate c1 = candidateList.get(i);
				if(c1.getName().equals(name)) {
					return c1;
				}
			}
			return null;
		}
		
	/**
	 * vote for specific candidate
	 * @param name
	 */
	
		public void voteForCandidate(String name) {
			if(getCandidate(name) == null) {
				System.out.println("Invalid candidate name!");
			}else {
				getCandidate(name).increaseVotes();
			}
		}
		
		/**
		 *vote for specific party of candidate
		 * 
		 */
	
		public void voteStraightTicket(String party) {
			boolean inList = true;
			for(int i = 0; i < candidateList.size(); i++) {
				Candidate current = candidateList.get(i);
				if(current.getParty().equals(party)) {
					current.increaseVotes();
					inList = false;
				}
			}
			if(inList) {
				System.out.println("Invalid party name!");
			}
		}
	/**
	 * get the information of the candidates including names and party affiliations
	 */
	 public void getCandidatesInformation() {
		 for (int i = 0;i < candidateList.size(); i++){
			 Candidate current = candidateList.get(i);
			 System.out.println(current.getName()+ " " + current.getParty());
		 }
	 }
	 
	 /**
	  * find the winner of the election without ties
	  * @return name the candidates name and information
	  */
	 public Candidate getWinner() {
		 if (candidateList.size() <= 0) {
			 System.out.println("no candidate in the election");
		 }else {
		Candidate current = candidateList.get(0);
		for (int index = 1; index <= candidateList.size()-1; index++) {
			Candidate now = candidateList.get(index);
			if(current.getVotes() < now.getVotes()) {
				current = now;
			} 
		}
		System.out.println(current.getName()+" "+current.getParty()+" "+current.getVotes());
		return current;
	  }
		return null;
		
		 
	 }
}
	