package comp132.examples.files.text;

import java.io.*;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * Some sample code that illustrates the basics of parsing a text file in Java.
 * This program reads the samples/DataFile.txt file that has the following
 * format:
 * 
 * <code>
 *   Town Name1,n,r1,r2,...,rn
 *   Town Name2,n,r1,r2,...,rn
 * </code>
 * 
 * n is the number of r values, each r value indicates a rainfall amount.
 * 
 * The proram reads and parses the DataFile.txt and outputs the ResultsFile.txt
 * with one line for each town giving the town name and the average rainfall.
 * 
 * @author Grant Braught
 * @author Dickinson College
 * @version October 21, 2016
 */
public class ParseTextFile {

	public static void main(String[] args) {
		String inFile = "src/comp132/examples/files/samples/DataFile.txt";
		String outFile = "src/comp132/examples/files/text/ResultsFile.txt";

		Scanner scr = null;
		PrintWriter pw = null;

		try {
			// Setup to read the input file
			scr = new Scanner(new FileInputStream(inFile));

			/*
			 * Set the delimiter(s) to be used by the Scanner to divide the
			 * tokens. Each character listed inside [...] is used as a
			 * delimiter. Here both ',' (comma) and '\n' (newline) are used as
			 * delimiters between tokens. We need both because the final double
			 * one each line is not delimited from the next town name by a comma
			 * but instead by a newline.
			 */
			scr.useDelimiter("[,\n]");

			// Setup to write to the output file.
			FileOutputStream fos = new FileOutputStream(outFile, false);
			pw = new PrintWriter(fos);

			/*
			 * Each time through the loop we read the next line of data,
			 * calculate the average and write out the town name and the
			 * average.
			 */
			while (scr.hasNext()) {
				String town = scr.next();

				try {
					int expectedCount = scr.nextInt();
					int actualCount = 0;
					double total = 0;

					for (int i = 0; i < expectedCount; i++) {
						try {
							total = total + scr.nextDouble();
							actualCount++;
						} catch (NoSuchElementException e) {
							// Scanner could not parse the Double.
							System.out.println("Bad rain data value for: " + town);
						}
					}

					double ave = total / actualCount;
					pw.println(town + "," + ave);

				} catch (NoSuchElementException e) {
					// Scanner could not parse the number of rain data
					System.out.println("Bad number of data values, skipping: " + town);
					scr.nextLine();  // skip rest of line.
				}
			}
		} catch (FileNotFoundException e) {
			// Could not create the input or output file.
			System.out.println(e.getMessage());
		} finally {
			// Close the input and output files.
			if (scr != null) {
				scr.close();
			}
			if (pw != null) {
				pw.close();
			}
		}
	}
}
