package comp132.examples.files.text;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

/**
 * Some sample code that illustrates the basics of reading and writing line
 * based data in text files using Java.
 * 
 * @author Grant Braught
 * @author Dickinson College
 * @version October 18, 2016
 */
public class FirstTextFileExamples {

	/**
	 * Create a new (or replace the existing) text file named firstFile.txt in
	 * the src/comp132/examples/files/text folder and write some text into it.
	 */
	public static void writeTextFile() {

		String filename = "src/comp132/examples/files/text/firstFile.txt";
		PrintWriter pw = null;

		try {
			/*
			 * Create a PrintWriter that will translate Java data (String, int,
			 * double, etc) into the bytes representing the ASCII values to be
			 * placed into the file.
			 * 
			 * The PrintWriter uses a FileOutputStream to write the bytes to the
			 * file. The second parameter indicates if new output should be
			 * appended to the file. True indicates that new output will be
			 * added to the end of the existing file. False indicates that if
			 * the file exists it will be overwritten (replaced).
			 * 
			 * The FileOutputStream constructor throws a FileNotFoundException,
			 * which is a checked exception, if the file cannot be opened.
			 */
			pw = new PrintWriter(new FileOutputStream(filename, false));

			/*
			 * Can use print or println on the PrintWriter object to output Java
			 * values to the text file.
			 * 
			 * Can you predict what the file contents will be?
			 */
			pw.println("This is a basic ASCII text file.");
			pw.print("Even numbers like ");
			pw.print(123);
			pw.print(" and ");
			pw.print(3.14);
			pw.println(" are put into ASCII.");
			pw.println("The \t End!");

		} catch (FileNotFoundException e) {
			/*
			 * The file could not be opened. Probably the path to the file
			 * specifies directories that do not exist.
			 */
			System.err.println("Unable to open the file: " + filename);
		} finally {
			/*
			 * The file must be closed when all writing is complete to be sure
			 * that all of the bytes are sent to the file. Otherwise the last
			 * bits of output might be lost. This needs to be done whether there
			 * was an exception or not, so it is in the finally block.
			 */
			if (pw != null) {
				pw.close();
			}
		}
	}

	/**
	 * Read the file named firstFile.txt in the src/comp132/examples/files/text
	 * folder and display each line with a line number.
	 */
	public static void readTextFile() {

		String filename = "src/comp132/examples/files/text/firstFile.txt";
		Scanner scr = null;

		try {
			/*
			 * Create a new scanner that will translate bytes read from the file
			 * into ASCII characters. The Scanner uses a FileInputStream to read
			 * the bytes from the file. The FileInputStream constructor will
			 * throw a FileNotFoundException, which is a checked exception, if
			 * the file does not exist.
			 */
			scr = new Scanner(new FileInputStream(filename));

			/*
			 * While there are more lines in the file, read one in and print it
			 * out preceded by the line number.
			 */
			int lineNum = 0;
			while (scr.hasNextLine()) {
				String line = scr.nextLine();
				System.out.println(lineNum + ": " + line);
				lineNum++;
			}

		} catch (FileNotFoundException e) {
			/*
			 * The file specified by the filename does not exist. This will
			 * happen if you delete the firstFile.txt file and then run this
			 * method.
			 */
			System.err.println("Unable to open the file: " + filename);
		} finally {
			/*
			 * Close the scanner because we are completely done with it. This
			 * needs to be done whether there is an exception or not, so it is
			 * in the finally block.
			 */
			if (scr != null) {
				scr.close();
			}
		}
	}
	
	public static void main(String[] args) {
		writeTextFile();
		readTextFile();
	}
}
