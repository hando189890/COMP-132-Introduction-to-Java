package comp132.examples.files.binary;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Some sample code that illustrates the basics of reading and writing binary
 * files using Java.
 * 
 * @author Grant Braught
 * @author Dickinson College
 * @version October 26, 2016
 */
public class FirstBinaryFileExamples {

	private static class RainRecord {
		public String locationID; // 5 chars - 7 bytes
		public double latitude; // 8 bytes
		public double longitude; // 8 bytes
		public float rain; // 4 bytes

		public static final int RECORD_SIZE = 7 + 8 + 8 + 4;

		public RainRecord(String loc, double lat, double lon, float rain) {
			locationID = loc;
			latitude = lat;
			longitude = lon;
			this.rain = rain;
		}
	}

	/**
	 * Write the RainRecords to the specified binary file.
	 * 
	 * @param records
	 *            list of RainRecord objects whose data is to be written to the
	 *            file.
	 * @param filename
	 *            path indicating the file where records are to be written.
	 */
	public static void writeBinaryFile(ArrayList<RainRecord> records, String filename) {
		DataOutputStream dos = null;
		try {
			dos = new DataOutputStream(new FileOutputStream(filename, false));

			/*
			 * For each RainRecord, write its constituent parts into the file.
			 */
			for (RainRecord r : records) {
				dos.writeUTF(r.locationID);
				dos.writeDouble(r.latitude);
				dos.writeDouble(r.longitude);
				dos.writeFloat(r.rain);
			}
		} catch (FileNotFoundException e) {
			/*
			 * Could not find the specified file. Likely a directory name is
			 * misspelled or the path given doesn't exist.
			 */
			System.out.println("Unable to open file: " + filename);
		} catch (IOException e) {
			/*
			 * One of the write methods encountered an error trying to write the
			 * data to the file (e.g. the disk was full or the drive was
			 * removed).
			 */
			System.out.println("Error writing to file: " + filename);
		} finally {
			/*
			 * If the dos was created (i.e. we did not have a
			 * FileNotFoundException) then we need to try to close the file. But
			 * closing a DataOutputStream can also throw an IOException, so we
			 * need another try/catch here.
			 */
			if (dos != null) {
				try {
					dos.close();
				} catch (IOException e) {
					System.out.println("Error closing file: " + filename);
				}
			}
		}
	}

	/**
	 * Read and display the RainRecords from the specified binary file.
	 * 
	 * @param filename
	 *            the file containing the RainRecords.
	 */
	public static void readBinaryFile(String filename) {
		DataInputStream dis = null;
		try {
			dis = new DataInputStream(new FileInputStream(filename));

			// Print a header row.
			System.out.println("LocID\tLat:Lon\t\tRain");

			/*
			 * As long as there are enough bytes in the file for another record,
			 * read the constituent parts of the record from the file.
			 */
			while (dis.available() >= RainRecord.RECORD_SIZE) {
				String loc = dis.readUTF();
				double lat = dis.readDouble();
				double lon = dis.readDouble();
				float rain = dis.readFloat();

				System.out.println(loc + "\t" + lat + ":" + lon + "\t" + rain);
			}
		} catch (FileNotFoundException e) {
			System.out.println("Unable to open file: " + filename);
		} catch (IOException e) {
			System.out.println("Error reading file: " + filename);
		} finally {
			if (dis != null) {
				try {
					dis.close();
				} catch (IOException e) {
					System.out.println("Error closing file: " + filename);
				}
			}
		}
	}

	/**
	 * Demonstrate the skip method by reading only the rainfall amounts from the
	 * file and computing the average.
	 * 
	 * @param filename
	 *            the file containing the RainRecords.
	 */
	public static void computeAverageRain(String filename) {
		DataInputStream dis = null;

		try {
			dis = new DataInputStream(new FileInputStream(filename));

			float total = 0;
			int count = 0;

			/*
			 * As long as there are enough bytes remaining in the file for
			 * another full record we can skip ahead to its rainfall value and
			 * read it.
			 */
			while (dis.available() >= RainRecord.RECORD_SIZE) {
				/*
				 * Skip to the rain value in the next record by skipping the
				 * location (UTF: 2 bytes + 5 chars), latitude (double: 8 bytes)
				 * and longitude (double: 8 bytes).
				 */
				dis.skip(7 + 8 + 8);
				float rain = dis.readFloat();
				total = total + rain;
				count++;
			}

			System.out.println("Ave Rain: " + (total / count));
		} catch (FileNotFoundException e) {
			System.out.println("Unable to open file: " + filename);
		} catch (IOException e) {
			System.out.println("Error reading file: " + filename);
		} finally {
			if (dis != null) {
				try {
					dis.close();
				} catch (IOException e) {
					System.out.println("Error closing file: " + filename);
				}
			}
		}
	}

	public static void main(String[] args) {
		ArrayList<RainRecord> records = new ArrayList<RainRecord>();
		records.add(new RainRecord("Carli", 40.2, 77.2, 0.23f));
		records.add(new RainRecord("Norwi", 52.6, 1.29, 1.07f));
		records.add(new RainRecord("Malag", 36.7, 4.42, 0.00f));
		records.add(new RainRecord("Bolog", 44.5, 11.3, 0.18f));
		records.add(new RainRecord("Tolou", 43.6, 1.44, 0.53f));

		String filename = "src/comp132/examples/files/binary/rain.dat";
		writeBinaryFile(records, filename);
		readBinaryFile(filename);
		computeAverageRain(filename);
	}
}
