package lab09.list;

/**
 * An implementation of the CS132List interface using an array of Objects.
 * 
 * @author 
 * @version 
 */
public class CS132ArrayList implements CS132List {

    private int size;
    private Object[] elems;
    
    /**
     * Construct a new empty CS132ArrayList.
     */
    public CS132ArrayList() {
    	elems = new Object[5];
    	size = 0;
    	
    	
        
    }

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public void add(Object element) {
		// TODO Auto-generated method stub
		
		if (size < elems.length) {
		elems[size] = element;
		size++;
		//System.out.println("Check size : " +size);
		}else {
			this.check();
			this.add(element);
		}
		
		
	}

	@Override
	public Object get(int index) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		return elems[index];
	}

	@Override
	public void set(int index, Object element) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		elems[index] = element; 
		
	}

	@Override
	public void insert(int index, Object element) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		
		if (size < elems.length) {
	    for (int i = elems.length-1; i > index; i--){
	       elems[i] = elems[i-1];
	    }
	      elems[index] = element;
	      size ++; 
		}else {
			this.check();
			this.insert(index, element);
		}
		
		
	}

	@Override
	public Object remove(int index) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
	
		for (int i = index; i < elems.length-1; i++){
	     elems[i] = elems[i+1];
	    }
	    elems[elems.length-1] = null;
	    size--;
	
	  return elems[index];  
  }
	
	private Object[] check() {
		if (size < elems.length) {
			return elems;
		}else {
				Object[] tmp = new Object[elems.length*2];
				System.arraycopy(elems, 0, tmp, 0, size);
				elems = tmp;
				return elems;
			}
		
	}
}
