package lab09.list;

/**
 * An implementation of the List interface using a singly linked list of
 * Objects.
 * 
 * @author 
 * @version
 */
public class CS132SinglyLinkedList implements CS132List {
	
	private SinglyLinkedNode head;
	private int size;

    /**
     * Construct a new empty CS132SinglyLinkedList.
     */
    public CS132SinglyLinkedList() {
    	//head.next = null;
    	size = 0;
    	
        
    }   
    
    /*
     * Structure used to represent a node in the linked list.
     */
    private static class SinglyLinkedNode {
        public SinglyLinkedNode next;
        public Object element;

        public SinglyLinkedNode(Object element) {
            this.element = element;
            next = null;
        }
    }

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	@Override
	public void add(Object element) {
		// TODO Auto-generated method stub
		
		if(size == 0) {
			SinglyLinkedNode newNode = new SinglyLinkedNode(element);
			head = newNode;
			size++;
		}else {
		SinglyLinkedNode cur = head;
		SinglyLinkedNode newNode = new SinglyLinkedNode(element);
        while (cur.next != null) {
    	   cur = cur.next;  
       }
       cur.next = newNode;
       size++;
		}
	}

	@Override
	public Object get(int index) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		SinglyLinkedNode cur = head;
        for (int i = 0; i < index; i++) {
            cur = cur.next;
        }
        return cur.element;
	}

	@Override
	public void set(int index, Object element) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		this.remove(index);
		this.insert(index, element);
	}

	@Override
	public void insert(int index, Object element) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		Object cur = this.get(index);
		SinglyLinkedNode curNode = new SinglyLinkedNode(cur);
		SinglyLinkedNode newNode = new SinglyLinkedNode(element);
		
		newNode.next = curNode.next;
        curNode.next = newNode;
        size++;
		
	}

	@Override
	public Object remove(int index) throws IndexOutOfBoundsException {
		// TODO Auto-generated method stub
		Object precur = this.get(index-1);
		SinglyLinkedNode precurNode = new SinglyLinkedNode(precur);
		Object cur = this.get(index);
		SinglyLinkedNode curNode = new SinglyLinkedNode(cur);
		precurNode.next = curNode.next;
		curNode.next = null;
        size--;
	    return curNode.element;
	}
	
}
