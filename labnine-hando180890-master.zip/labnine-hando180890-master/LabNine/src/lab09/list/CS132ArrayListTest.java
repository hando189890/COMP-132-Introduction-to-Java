package lab09.list;

import static org.junit.Assert.*;
import org.junit.*;

public class CS132ArrayListTest {
	//private ArrayList<Object> myList;
	private String e1;
	private String e2;
	private String e3;
	private String e4;
	private String e5;
	private String e6;
	
	

	/*
	 * The myList field can refer to any object that implements the CS132List
	 * interface (e.g. a CS132ArrayList or a CS132LinkedList). In this class it
	 * is set in the setUp method to refer to a CS132ArrayList.
	 * 
	 * If you use CS132List referred to my myList in all of your tests in this
	 * class and also use only the methods in the CS132List interface, then the
	 * CS132SinglyLinkedListTest class that you are given will run all of your
	 * tests against your CS132LinkedList class as well. Thus, you will only
	 * need to create one set of tests!
	 * 
	 * Be sure to look at the CS132SinglyLinkedListTest class to see how this
	 * works! Its pretty clever!
	 */
	protected CS132List myList;

	@Before
	public void setUp() throws Exception {
		myList = new CS132ArrayList();
		e1 = "a";
		e2 = "b";
		e3 = "c";
		e4 = "d";
		e5 = "e";
		e6 = "f";
		
	}

	@Test
	public void testConstructor() {
		assertEquals(0, myList.size());
	}
	
	@Test
	public void testAdd() {
		myList.add(e1);
		myList.add(e2);
		myList.add(e3);
		assertEquals(3, myList.size());
	}
	@Test
	public void testGet() {
		myList.add(e1);
		myList.add(e2);
		myList.add(e3);
		myList.add(e4);
		myList.add(e5);
		assertEquals(5, myList.size());
		assertEquals(e3, myList.get(2));
		
	}
	@Test
	public void testSet() {
		myList.add(e1);
		myList.add(e2);
		myList.add(e3);
		myList.add(e4);
		myList.add(e5);
		assertEquals(5, myList.size());
		assertEquals(e3, myList.get(2));
		myList.set(2, e6);
		assertEquals(e6, myList.get(2));
	}
	
	@Test
	public void testInsert() {
		myList.add(e1);
		myList.add(e2);
		myList.add(e3);
		myList.add(e4);
		assertEquals(4, myList.size());
		assertEquals(e3, myList.get(2));
		myList.insert(2, e5);
		assertEquals(e5, myList.get(2));
		assertEquals(5, myList.size());
		
	}
	
	@Test
	public void testMove() {
		myList.add(e1);
		myList.add(e2);
		myList.add(e3);
		myList.add(e4);
		assertEquals(4, myList.size());
		assertEquals(e3, myList.get(2));
		myList.remove(2);
		//assertEquals(e4, myList.remove(2));
		assertEquals(3, myList.size());
	}   
	
	@Test
	public void testAddExcessive() {
		myList.add(e1);
		myList.add(e2);
		myList.add(e3);
		myList.add(e4);
		myList.add(e5);
		assertEquals(5, myList.size());
		myList.add(e6);
		assertEquals(e6, myList.get(5));
		assertEquals(6, myList.size());
	}
}
