package lab03.shapes;

import java.awt.*;

/**
 * This class prints a  square with specific color
 * @author DONGBING & MANH
 * @version 2019.2.17
 */
public class Square implements Drawable {

    private int x;
    private int y;
    private int a;
    private Color theColor;
    private boolean isVisible;


    /**
     * Construct a new square with sides a with color indicated by initColor. 
     * The new Square is visible by default.
     * 
     * @param initA the length of a side of the square.
     * @param initX the x coordinate of the corner of the square.
     * @param initY the x coordinate of the corner of the square.
     * @param initColor the color of the square
     * 
     * 
     */
    public Square(int initX, int initY, int initA, Color initColor) {
        a = initA;        
        x = initX;
        y = initY;
        //radius = initRadius;
        theColor = initColor;
        isVisible = true;   
       // isSvisible = true;
        
        //x2 = x-a/2;
        //y2 = y-a/2;
        

    }

    /**
     * Get the length of a of this Square.
     * 
     * @return the a length
     */
    public int getLength() {
        return a;
    }
    
        /**
         * Get the x coordinate of the center of this square.
         * 
         * @return the x coordinate
         */
        public int getX() {
            return x;
        }

        /**
         * Get the y coordinate of the center of this square.
         * 
         * @return the y coordinate
         */
        public int getY() {
            return y;
        }



        /**
         * Move the square to a new location. 
         * 
         * @param newX the new x coordinate
         * @param newY the new y coordinate
         */
        public void move(int newX, int newY) {
            x = newX;
            y = newY;
           
            
        }

        /**
         * Move the square  to relative to its current location. 
         * location.
         * 
         * @param deltaX the change in the x coordinate. Positive values move the
         *            square to the right, negative values move it to the left.
         * @param deltaY the change in the y coordinate. Positive values move the
         *            square down, negative values move it up.
         */
        public void translate(int deltaX, int deltaY) {
            x = x + deltaX;
            y = y + deltaY;
           
            
        }
        
        

       // === Implementation of the Drawable interface ===

        /** 
         * Draw this DrawableCircle onto the specified Graphics object.
         * 
         * @param g the Graphics object on which to draw this DrawableCircle.
        */
        public void draw(Graphics g) {
            g.setColor(getColor());
        	g.fillRect(x, y, a, a);
        	
        }
        
        
        

        /**
         * Get the Color of this square.
         * 
         * @return the color.
         */
        public Color getColor() {
            return theColor;
        }

        /**
         * Change the color of this square to the newColor.
         * 
         * @param newColor the new color.
         */
        public void setColor(Color newColor) {
            theColor = newColor;
        }

        /**
         * Set whether or not this square will be visible. If it is visible its draw
         * method will be invoked when the DrawingTablet is repainted. If it is not
         * visible its draw method will not be invoked.
         * 
         * @param visible true to make this square visible, false to make it
         *            invisible.
         */
        public void setVisible(boolean visible) {
            isVisible = visible;
        }

        /**
         * Find out if this square is visible or not.
         * 
         * @return true if the square is visible, false if it is not.
         */
        public boolean isVisible() {
            return isVisible;
            
        }
    }

