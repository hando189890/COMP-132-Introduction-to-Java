package lab03.shapes;

import java.awt.Color;
import java.awt.Graphics;

	/**
	 * A rectangle is an object representing a square. A square has two side long and short
	 * and a color. It can be moved, translated, scaled and drawn.
	 * 
	 * @author Dongbing & Manh
	 * @version 2019.2.13
	 */
public class Rectangle implements Drawable, Scaleable {

	    private int l;
	    private int s;
	    private Color theColor;
	    private boolean isVisible;
	    private int x;
	    private int y;

	    /**
	     * Construct a rectangle with initial long and short side and color
	     * the x, y coordinates represent the upper left corner of the the square
	     *  which is its location
	     * 
	     * @param initL the long side
	     * @param initS the short side
	     * @param color the color .
	     * @param x the x coordinates
	     * @param y the y coordinates
	     */
	    public Rectangle(int initL, int initS, Color color, int x, int y) {
	        l = initL;
	        s = initS;
	    	theColor = color;
	    	this.x = x;
	    	this.y = y;
	        isVisible = true;
	    }

	    /**
	     * Get long side of rectangle
	     * 
	     * @return l the long side
	     */
	    public int getLength() {
	        return l;
	    }

	    /**
	     * Get short side of rectangle
	     * 
	     * @return s the short side
	     */
	    public int getWidth() {
	        return s;
	    }
	    
	    /**
	     * Get the x coordinate of the center of this rectangle
	     * 
	     * @return the x coordinate
	     */
	    public int getX() {
	        return x;
	    }

	    /**
	     * Get the y coordinate of the center of this rectangle
	     * 
	     * @return the y coordinate
	     */
	    public int getY() {
	        return y;
	    }

	    /**
	     * Move the Circle to a new location. T
	     * 
	     * @param newX the new x coordinate
	     * @param newY the new y coordinate
	     */
	    public void move(int newX, int newY) {
	        x = newX;
	        y = newY;
	    }

	    /**
	     * Move the rectangle relative to its current location. The right upper corner of the
	     * rectangle is moved by adding the parameters to the rectangle current
	     * location.
	     * 
	     * @param deltaX the change in the x coordinate. Positive values move the
	     *           to the right, negative values move it to the left.
	     * @param deltaY the change in the y coordinate. Positive values move the
	     *           down, negative values move it up.
	     */
	    public void translate(int deltaX, int deltaY) {
	        x = x + deltaX;
	        y = y + deltaY;
	    }
	    
	    // === Implementation of the Scaleable interface ===
	    /**
	     * Scale this rectangle by the specified factor. For example a factor of 2.0
	     * will make the radius twice as bit and a factor of 0.5 will make it half
	     * as large. If the factor is negative the radius is not changed.
	     * 
	     * @param factor the factor by which this rectangle is to be scaled.
	     */
	    public void scale(double factor) {
	        if (factor > 0) {
	            l = (int) (Math.round(l * factor));
	            s = (int) (Math.round(s * factor));
	        }
	    }

	    // === Implementation of the Drawable interface ===

	    /**
	     * Draw this DrawableCircle onto the specified Graphics object.
	     * 
	     * @param g the Graphics object on which to draw this DrawableCircle.
	     */
	    public void draw(Graphics g) {
	        g.setColor(getColor());
	        g.fillRect(x, y, l, s);
	    }

	    /**
	     * Get the Color of this Circle.
	     * 
	     * @return the color.
	     */
	    public Color getColor() {
	        return theColor;
	    }

	    /**
	     * Change the color of this Circle to the newColor.
	     * 
	     * @param newColor the new color.
	     */
	    public void setColor(Color newColor) {
	        theColor = newColor;
	    }

	    /**
	     * Set whether or not this square will be visible. If it is visible its draw
	     * method will be invoked when the DrawingTablet is repainted. If it is not
	     * visible its draw method will not be invoked.
	     * 
	     * @param visible true to make this square visible, false to make it
	     *            invisible.
	     */
	    public void setVisible(boolean visible) {
	        isVisible = visible;
	    }

	    /**
	     * Find out if this Circle is visible or not.
	     * 
	     * @return true if the Circle is visible, false if it is not.
	     */
	    public boolean isVisible() {
	        return isVisible;
	    }
	}
