package lab03.shapes;

import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Before;
import org.junit.Test;

public class SquareTest {
	
	private Square s1;

	 @Before
	    public void setUp() throws Exception {
	        /*
	         * Construct all of the objects being used in the test fixture here.
	         */
		 
		 s1 = new Square(2, 1, 5, Color.blue);
	    } 

	@Test
	public void testConstructor() {
		assertEquals(5, s1.getLength());
		//assertEquals(4, s1.getWidth());
		assertEquals(2, s1.getX());
		assertEquals(1, s1.getY());
		assertEquals(Color.blue, s1.getColor());
	}
	
	@Test
	public void testMove() {
		s1.move(10, 11);
		assertEquals(10, s1.getX());
		assertEquals(11, s1.getY());
	}
	
	@Test
	public void testTraslatePositive() {
		s1.translate(10, 20);
		assertEquals(12, s1.getX());
		assertEquals(21, s1.getY());
	}
	
	@Test
	public void testTraslatePositiveNegative() {
		s1.translate(-1, -2);
		assertEquals(1, s1.getX());
		assertEquals(-1, s1.getY());
	}
	
//	@Test  
//    public void testScale() {
//        s1.scale(2.0);
//        assertEquals(10, s1.getLength());
//		assertEquals(8, s1.getWidth());
//        
//        s1.scale(0.5);
//        assertEquals(3, s1.getLength());
//		assertEquals(2, s1.getWidth());
//		
//        s1.scale(-2.0);
//        assertEquals(5, s1.getLength());
//		assertEquals(4, s1.getWidth());
//    }
	
	 @Test
	    public void testSetVisible() {
	        s1.setVisible(false);
	        assertFalse("should be invisible", s1.isVisible());
	        
	        s1.setVisible(true);
	        assertTrue("should be visible", s1.isVisible());
	    }
	
	 @Test
	    public void testSetColor() {
	        s1.setColor(Color.red);
	        assertEquals(Color.red, s1.getColor());     
	    }
}
