package lab03.shapes;

import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Before;
import org.junit.Test;

public class TriangleTest {
	
	
	private Triangle s1;

	 @Before
	    public void setUp() throws Exception {
	        /*
	         * Construct all of the objects being used in the test fixture here.
	         */
		 
		    s1 = new Triangle(10, 20, 30, 40, 50, 60, Color.blue);
	    } 
	
	

	@Test
	public void testConstructor() {
		assertEquals(10, s1.getFX());
		assertEquals(20, s1.getFY());
		assertEquals(30, s1.getSX());
		assertEquals(40, s1.getSY());
		assertEquals(50, s1.getTX());
		assertEquals(60, s1.getTY());
	}

	@Test
	public void testMove() {
		s1.move(30, 40, 50, 60, 70, 80);
		assertEquals(30, s1.getFX());
		assertEquals(40, s1.getFY());
		assertEquals(50, s1.getSX());
		assertEquals(60, s1.getSY());
		assertEquals(70, s1.getTX());
		assertEquals(80, s1.getTY());
	}
	
	@Test
	public void testTranslate() {
		s1.translate(10, 10, -15, -5, 0, 0);
		assertEquals(20, s1.getFX());
		assertEquals(30, s1.getFY());
		assertEquals(15, s1.getSX());
		assertEquals(35, s1.getSY());
		assertEquals(50, s1.getTX());
		assertEquals(60, s1.getTY());
		
	}
	
	
	@Test
    public void testSetVisible() {
        s1.setVisible(false);
        assertFalse("should be invisible", s1.isVisible());
        
        s1.setVisible(true);
        assertTrue("should be visible", s1.isVisible());
    }

   @Test
    public void testSetColor() {
        s1.setColor(Color.red);
        assertEquals(Color.red, s1.getColor());     
    }
	
}
