package lab03.shapes;

import java.awt.Color;

public class Train {
	
	/**
	 * This class is try to draw a simple train with simple pictures that i have create in the lab
	 * assignment. Basically, the train is consist of square and circle. 
	 * @author Dongbing & Manh
	 * @version 2019.2.16
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 /*
         * Create a DrawableObject list and use it to create a DrawingTablet.
         */
        DrawableObjectList objList = new DrawableObjectList();
        DrawingTablet tablet = new DrawingTablet("Train", 200, 200, objList);

        // Create pictures on screen.
        Circle sun = new Circle(15, 15, 10, Color.red);
        Circle w1 = new Circle(20, 190, 10, Color.black);
        Circle w2 = new Circle(50, 190, 10, Color.black);
        Circle w3 = new Circle(76, 190, 10, Color.black);
        Circle w4 = new Circle(106, 190, 10, Color.black);
        Circle w5 = new Circle(132, 190, 10, Color.black);
        Circle w6 = new Circle(162, 190, 10, Color.black);
        Circle ww1 = new Circle(20, 100, 8, Color.white);
        Circle ww2 = new Circle(30, 80, 5, Color.white);
        Rectangle s1 = new Rectangle(56, 40, Color.green, 7, 145);
        Rectangle s2 = new Rectangle(56, 40, Color.red, 63, 145); 
        Rectangle s3 = new Rectangle(56, 40, Color.green, 119, 145);
        Rectangle s4 = new Rectangle(12, 25, Color.black, 7, 120);
        //Triangle t1 = new Triangle(20, 30, 50, 30, 20, 60, Color.BLACK);
        
        objList.addDrawable(sun);
        objList.addDrawable(w1);
        objList.addDrawable(w2);
        objList.addDrawable(w3);
        objList.addDrawable(w4);
        objList.addDrawable(w5);
        objList.addDrawable(w6);
        objList.addDrawable(ww1);
        objList.addDrawable(ww2);
        objList.addDrawable(s1);
        objList.addDrawable(s2);
        objList.addDrawable(s3);
        objList.addDrawable(s4);
        //objList.addDrawable(t1);
        
        tablet.repaint();
	}

}
