package lab03.shapes;

import java.awt.Color;
import java.awt.Graphics;

	/**
	 * Create a triangle class with has three sides , three corners
	 * and a color. It can be moved, translated and drawn.
	 * 
	 * @author Dongbing & Manh
	 * @version 2019.2.13
	 */
public class Triangle implements Drawable {

	    private int x1;
	    private int y1;
	    private Color theColor;
	    private boolean isVisible;
	    private int x2;
	    private int y2;
	    private int x3;
	    private int y3;
	    private double height;

	    /**
	     * Construct a triangle with all the initial information including coordinates of corner and color
	     * and set it visible
	     * 
	     * @param x2 the x2 coordinates
	     * @param y2 the y2 coordinates
	     * @param x3 the x3 coordinates
	     * @param y3 the y3 coordinates
	     * @param initS the short side
	     * @param color the color .
	     * @param x1 the x1 coordinates
	     * @param y1 the y1 coordinates
	     */
	    public Triangle (int x1, int y1, int x2, int y2, int x3, int y3,  Color color) {
	       this.x1 = x1;
	       this.y1 = y1;
	       this.x2 = x2;
	       this.y2 = y2;
	       this.x3 = x3;
	       this.y3 = y3;
	       height = Math.abs(y2-y1);
	       theColor = color;
	       isVisible = true;
	    }

	    /**
	     * get the x coordinates of first corner
	     * 
	     * @return x1
	     */
	    public int getFX() {
	        return x1;
	    }

	    /**
	     * get the y coordinates of the first corner
	     * 
	     * @return y1
	     */
	    public int getFY() {
	        return y1;
	    }
	    
	    
	    /**
	     * get the x coordinates of second corner
	     * 
	     * @return x2
	     */
	    public int getSX() {
	        return x2;
	    }

	    /**
	     * get the y coordinates of the second corner
	     * 
	     * @return y2
	     */
	    public int getSY() {
	        return y2;
	    }
	    
	    /**
	     * get the x coordinates of third corner
	     * 
	     * @return x3
	     */
	    public int getTX() {
	        return x3;
	    }

	    /**
	     * get the y coordinates of the third corner
	     * 
	     * @return y3
	     */
	    public int getTY() {
	        return y3;
	    }
	    
	    
	    /**
	     * Move the triangle to a new location by setting new corner coordinates
	     * 
	     * @param newX1 the new x coordinate
	     * @param newY1 the new y coordinate
	     * 
	     * @param newX2 the new x2 coordinate
	     * @param newY2 the new y2 coordinate
	     * 
	     * @param newX3 the new x3 coordinate
	     * @param newY3 the new y3 coordinate
	     */
	    public void move(int newX1, int newY1, int newX2, int newY2, int newX3, int newY3) {
	        x1 = newX1;
	        y1 = newY1;
	        x2 = newX2;
	        y2 = newY2;
	        x3 = newX3;
	        y3 = newY3;
	        
	    }

	    /**
	     * Move triangle to new place by entering the distance it want to move.
	     * x Positive values move to the right, negative values move it to the left
	     * y Positive values move down, negative values move it up.
	     * 
	     * @param deltaX1 
	     * @param deltaY1           
	     * @param deltaX2 
	     * @param deltaY2 
	     * @param deltaX3 
	     * @param deltaY3
	     */
	    public void translate(int deltaX1, int deltaY1, int deltaX2, int deltaY2, int deltaX3, int deltaY3) {
	        x1 = x1 + deltaX1;
	        y1 = y1 + deltaY1;
	        x2 = x2 + deltaX2;
	        y2 = y2 + deltaY2;
	        x3 = x3 + deltaX3;
	        y3 = y3 + deltaY3;
	        
	        
	    }
	    
	    // === Implementation of the Drawable interface ===

	    /**
	     * Draw this DrawableCircle onto the specified Graphics object.
	     * 
	     * @param g the Graphics object on which to draw this DrawableCircle.
	     */
	    public void draw(Graphics g) {
	        g.setColor(getColor());
	        g.fillPolygon (new int[] {x1, x2, x3}, new int[] {y1, y2, y3}, 3);
	    }

	    /**
	     * Get the Color of this triangle.
	     * 
	     * @return the color.
	     */
	    public Color getColor() {
	        return theColor;
	    }

	    /**
	     * Change the color of this triangle.
	     * 
	     * @param newColor 
	     */
	    public void setColor(Color newColor) {
	        theColor = newColor;
	    }

	    /**
	     * Set whether or not this triangle will be visible. If it is visible its draw
	     * method will be invoked when the DrawingTablet is repainted. If it is not
	     * visible its draw method will not be invoked.
	     * 
	     * @param visible true to make this triangle visible, false to make it
	     *            invisible.
	     */
	    public void setVisible(boolean visible) {
	        isVisible = visible;
	    }

	    /**
	     * Find out if this triangle is visible or not.
	     * 
	     * @return true if the triangle is visible, false if it is not.
	     */
	    public boolean isVisible() {
	        return isVisible;
	    }
}

