package lab03.shapes;

import static org.junit.Assert.*;

import java.awt.Color;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

public class DrawableObjectListTest {
	private DrawableObjectList l1;
	private Circle c1;
	private Circle c2;
	private Square c3;
	  
	
	@Before
    public void setUp() throws Exception {
        /*
         * Construct all of the objects being used in the test fixture here.
         */
	 
	  l1 = new DrawableObjectList(); 
	  c1 = new Circle(2, 3, 3, Color.red); 
	  c2 = new Circle(3, 4, 4, Color.black);
	  c3 = new Square(1, 2, 3, Color.red);
	  
	  
    } 

	@Test
	public void testConstrctor() {
		assertEquals(0, l1.getSize());
	}
	
	@Test
	public void testAddDrawable() {
		Drawable d1 = c1;
		l1.addDrawable(d1);
		assertEquals(1, l1.getSize());
	}
	
	@Test
	public void testRemove() {
		Drawable d1 = c1;
		l1.addDrawable(d1);
		l1.removeDrawable(d1);
		assertEquals(0, l1.getSize());
	}
	

	@Test
	public void testScaleAll() {
		Drawable d1 = c1;
		Drawable d2 = c2;
		Drawable d3 = c3;
		l1.addDrawable(d1);
		l1.addDrawable(d2);
		l1.addDrawable(d3);
		l1.scaleAll(2);
		assertEquals(6, c1.getRadius());
		assertEquals(8, c2.getRadius());
		assertEquals(3, c3.getLength());
	}

}
