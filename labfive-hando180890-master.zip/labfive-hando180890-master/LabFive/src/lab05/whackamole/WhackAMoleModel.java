package lab05.whackamole;

import java.util.*;

/**
 * A model (in the MVC sense) for a whack-a-mole game. The model keeps track of
 * the location of the mole. It has a method for whacking a location and handles
 * scoring points and moving the mole if it was there and deducting points if
 * the mole was not there.
 * 
 * @author Grant Braught
 * 
 * @author Dongbing & Son
 * @version 2019.3.25
 */
public class WhackAMoleModel extends Observable {
	private int rows;
	private int cols;
	private int score;
	private int molCol;
	private int molRow;
	private int curMolCol;
	private int curMolRow;
    /**
     * Construct a new 4x4 Whack-a-Mole board. The mole is initially at a
     * randomly selected location. The score is initially 0.
     */
    public WhackAMoleModel() {
    	Random rand = new Random();
    	rows = 4;
    	cols = 4;
    	score = 0;
    	molCol = rand.nextInt(3);
    	molRow = rand.nextInt(3);
    }

    /**
     * Get the number of rows on the board.
     * 
     * @return the number of rows.
     */
    public int getRows() {
        return rows;
    }

    /**
     * Get the number of columns on the board.
     * 
     * @return the number of columns.
     */
    public int getCols() {
        return cols;
    }
    
    /**
     * Get the row containing the mole.
     * 
     * @return the row containing the mole.
     */
    public int getMoleRow() {
        return molRow;
    }

    /**
     * Get the column containing the mole.
     * 
     * @return the column containing the mole.
     */
    public int getMoleCol() {
        return molCol;
    }

    /**
     * Get the current score.
     * 
     * @return the score.
     */
    public int getScore() {
        return score;
    }

    /**
     * Whack the hole at the specified row and column. When a hole is whacked
     * the score is increased if there was a mole at that location and decreased
     * if there was not. Either way the location of the mole is changed and any
     * observers are notified of the change.
     * 
     * @param row the row to whack
     * @param col the column to whack
     */
    public void whack(int row, int col) {
    	if (row == molRow && col == molCol ) {
    		System.out.println("check");  
    		score = score + 10;
    		Random rand = new Random();
    		curMolCol = molCol;
    		molCol = rand.nextInt(3);
    		curMolRow = molRow;
    		molRow = rand.nextInt(3);
    		//score = score + 10;
    		if (molCol == curMolCol && molRow == curMolRow) {
        		molCol = rand.nextInt(3);
        		molRow = rand.nextInt(3);
    		}
    	} else {
    		Random rand = new Random();
    		curMolCol = molCol;
    		molCol = rand.nextInt(3);
    		curMolRow = molRow;
    		molRow = rand.nextInt(3);
    		score = score - 5;
    		if (molCol == curMolCol && molRow == curMolRow) {
        		molCol = rand.nextInt(3);
        		molRow = rand.nextInt(3);
    		}
    	}
    	
    }
}
