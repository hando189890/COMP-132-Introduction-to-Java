package lab05.whackamole;

import static org.junit.Assert.*;

import java.awt.Color;

import org.junit.Before;
import org.junit.Test;



public class WhackAMoleModelTest {
	private WhackAMoleModel w1;
	 @Before
	    public void setUp() throws Exception {
	        w1 = new WhackAMoleModel();
	    }
	    
	    @Test
	    public void testConstructor() {
	        assertEquals("wrong columns", 4, w1.getCols());
	        assertEquals("wrong rows", 4, w1.getRows());
	        assertEquals("wrong score", 0, w1.getScore());
	    }
	    
}  