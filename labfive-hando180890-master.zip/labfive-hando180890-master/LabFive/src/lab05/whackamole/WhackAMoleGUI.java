package lab05.whackamole;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
import javax.swing.plaf.basic.BasicOptionPaneUI.ButtonActionListener;

/**
 * A GUI for the Whack-a-Mole game.
 *
 * @author Grant Braught
 * 
 * @author Dongbing & Son
 * @version 2019.3.25
 */
@SuppressWarnings("serial")
public class WhackAMoleGUI extends JFrame implements Observer {
	private JButton[][] whackGUI;
	private WhackAMoleModel myModel;
	private ImageIcon hole;
	private ImageIcon mole;
	//private JPanel panel1;
	private JLabel score;
	

	/**
	 * Construct a new WhackAMoleGUI for the specified model.
	 * 
	 * @param myModel the model for this GUI.
	 */
	public WhackAMoleGUI(WhackAMoleModel myModel) {
		super("Whack-A-Mole");
		this.myModel = myModel;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myModel.addObserver(this);
		
		mole = new ImageIcon(WhackAMoleGUI.class.getResource("icons/gopher.jpg"));
		hole = new ImageIcon(WhackAMoleGUI.class.getResource("icons/hole.jpg"));
		whackGUI = new JButton[myModel.getRows()][myModel.getCols()];
		//JButton[][] whackGUI = new JButton[4][4];
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		this.add(mainPanel);
		//mainPanel.add(getComponentScore());
	
		score = new JLabel("Score: " + myModel.getScore());
		mainPanel.add(score);
		
		for (int i=0; i <=3; i++) {
		mainPanel.add(getComponentButton(i));
		}
		
		whackGUI[myModel.getMoleRow()][myModel.getMoleCol()].setIcon(mole);
		this.pack();

	}

//	private JPanel getComponentScore() {
//		myModel = new WhackAMoleModel();
//		//JLabel score = new JLabel("Score: " + myModel.getScore());
//		score = new JLabel("Score: " + myModel.getScore());
//		//score.setText("myModel.getScore()");
//		
//		JPanel panel1 = new JPanel();
//		panel1.setLayout(new BoxLayout(panel1, BoxLayout.X_AXIS));
//		panel1.add(score);
//		return panel1;
//	}
	
	private JPanel getComponentButton(int row) {
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
		for (int j = 0; j < 4; j++) {
			
				JButton button = new JButton(hole);
				buttonPanel.add(button);
				whackGUI[row][j] = button;
				ButtonListener bl = new ButtonListener(row,j);
				button.addActionListener(bl);
			}
			/*
			 * Add the components, rigid areas and glue as desired.
			 */
		
		return buttonPanel;
	}
	
	

//	private JPanel getComponentButton() {
//		JPanel buttonPanel = new JPanel();
//		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
//		for (int i = 0; i < 4; i++) {
//			
//			JPanel panel = new JPanel();
//			panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
//
//			/*
//			 * Add the components, rigid areas and glue as desired.
//			 */
//			panel.add(Box.createHorizontalGlue());
//			for (int j = 0; j < 4; j++) {
//				JButton button = new JButton(hole);
//				panel.add(button);
//				whackGUI[i][j] = button;
//				ButtonListener bl = new ButtonListener(i,j);
//				button.addActionListener(bl);
//			}
//
//			buttonPanel.add(panel);
//
//		}
//		return buttonPanel;
//}
		
		
		
//		JPanel buttonPanel = new JPanel();
//		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
//		for (int i = 0; i < 4; i++) {
//			buttonPanel.add(rowPaneli));
//		}
//		return buttonPanel;
//	}
//	
//	private JPanel rowPaneli() {
//			JPanel panel = new JPanel();
//			panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
//
//			/*
//			 * Add the components, rigid areas and glue as desired.
//			 */
//			panel.add(Box.createHorizontalGlue());
//			for (int j = 0; j < 4; j++) {
//				JButton button = new JButton(hole);
//				panel.add(button);
//				whackGUI[i][j] = button;
//				ButtonListener bl = new ButtonListener(i,j);
//				button.addActionListener(bl);
//			}
//
//			buttonPanel.add(panel);
//
//		}
//		return buttonPanel;
//	}
//	}
		
		
	

	/**
	 * Update the GUI to reflect the state of the model. This method repaints all of
	 * the buttons with a hole and then repaints the button with the mole on it.
	 */
	public void update(Observable o, Object arg) {
//		String st = Integer.toString(myModel.getScore());
//		System.out.println("check: " +st);
		score.setText("Score: " + myModel.getScore());
		
		
		//score = new JLabel("Score: " + myModel.getScore());
	}
		//score.setText(myModel.getScore());
//		for (int i = 0; i < 4; i++) {
//			for (int j = 0; j < 4; j++) {
//				whackGUI[i][j].setIcon(hole);
//			}
//		}
//		whackGUI[myModel.getMoleRow()][myModel.getMoleCol()].setIcon(mole);
	

//		private class b1Listener implements ActionListener {
//
//			@Override
//			public void actionPerformed(ActionEvent arg0) {
//				whackGUI[myModel.getMoleRow()][myModel.getMoleCol()].setIcon(mole);
//				myModel.getScore();
//			}
//		}
//		}

	/**
	 * Run the WhackAMole game.
	 * 
	 * @param args none
	 */
	public static void main(String[] args) {
		WhackAMoleModel wamm = new WhackAMoleModel();
		WhackAMoleGUI gui = new WhackAMoleGUI(wamm);
		gui.setVisible(true);
	}

	private class ButtonListener implements ActionListener {
		private int row;
		private int col;
		
		public ButtonListener(int row, int col) {
			this.row = row;
			this.col = col;
		}
		@Override
		public void actionPerformed(ActionEvent arg0) {
			myModel.whack(row, col);
			System.out.println("Click- row: " + row + ", col:" + col);
			for (int i = 0; i < 4; i++) {
				for (int j = 0; j < 4; j++) {
					whackGUI[i][j].setIcon(hole);
				}
			}
			whackGUI[myModel.getMoleRow()][myModel.getMoleCol()].setIcon(mole);
//			whackGUI[myModel.getMoleRow()][myModel.getMoleCol()].setIcon(mole);
//			whackGUI[row][col].setIcon(hole);
			System.out.println("Current Score: " + myModel.getScore());
			String st = Integer.toString(myModel.getScore());
			//System.out.println("check: " +st);
			score.setText("Score: " + st);
			
			
		}
	}
}
