package hw03;


// Create a generic class named Pair in your hw03 package. 
//The Pair class is able to store and retrieve two values. 
//The types of these values must be specified by type parameters. 

public class Pair<T,U> {
	private T v1;
	private U v2;

	public Pair(T v1, U v2) {//A constructor that allows the two values to be specified as parameters.
		this.v1 = v1;
		this.v2 = v2;
	}
	
	public T getFirst() {//returns the first value
		return v1;
	}    
	
	public U getSecond() {//returns the value of the second value 
		return v2;
	}
	
	public void setFirst(T v) {//changes the value of the first value 
		this.v1 = v;
	}
	
	public void setSecond(U v) {//changes the value of the second value 
		this.v2 = v;
	}
	
	public static void main(String[] args) {
		//A variable intPair that refers to a Pair object that holds two Integer objects. 
		//Pair intPair = new Pair(1, 2);
		Pair<Integer, Integer> intPair = new Pair<Integer, Integer>(1,2);
		//A variable mixPair that refers to a Pair object that holds a Double object and a String object. 
		//Pair mixPair = new Pair(1.2, 'X');
		Pair<Double, String> mixPair = new Pair<Double, String>(1.2, "X");
		//A variable pairPair that refers to a Pair object that holds two Pair objects, one as defined in part i, and the other as defined in part ii. 
		//Pair pairPair = new Pair(intPair, mixPair);
		Pair<Pair<Integer, Integer>, Pair<Double, String>> pairPair = new Pair<Pair<Integer, Integer>, Pair<Double, String>>(intPair,mixPair);

	}
	
}
