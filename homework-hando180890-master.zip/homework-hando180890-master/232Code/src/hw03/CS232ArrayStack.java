package hw03;

public class CS232ArrayStack<E> extends CS232ArrayList<E> implements CS232Stack<E> {

	private CS232List<E> list;

	public CS232ArrayStack() {
		list = new CS232ArrayList<E>();
	}

	@Override
	public void push(E item) {
		list.insert(list.size(), item);
	}

	@Override
	public E pop() {
		if (list.size() == 0) {
			return null;
		} else if (list.size() > 0) {
			return list.remove(list.size() - 1);
		}
		return null;

	}

	@Override
	public E peek() throws Exception {
		if (list.size() > 0) {
			return list.get(list.size() - 1);
		} else {
			return null;
		}
	}

	public int size() {
		return list.size();
	}

}
