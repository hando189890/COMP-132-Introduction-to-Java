package Lab1;



import java.io.*;    
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

import org.junit.Test;

import static org.junit.Assert.*;




public class solveMeFirst {


    static int solveMeFirst(int a, int b) {
		return a+b;
      	// Hint: Type return a+b; below 

   }      

 public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a;
        a = in.nextInt();  
        int b;
        b = in.nextInt();
        int sum;
        sum = solveMeFirst(a, b);
        System.out.println(sum);
    }
    

   @Test
    public void testCorrect() {
	int a = 3;
	int b = 2;
	assertEquals(5, solveMeFirst.solveMeFirst(a, b));
    }
   
   @Test
   public void testEquals0() {
	int a = 0;
	int b = 0;
	assertEquals(0, solveMeFirst.solveMeFirst(a, b));
   }
   
   @Test
   public void testNegative() {
	int a = -1;
	int b = 0;
	assertEquals(-1, solveMeFirst.solveMeFirst(a, b));
   }
   
   @Test
   public void testDubNegative() {
	int a = -1;
	int b = -3;
	assertEquals(-4, solveMeFirst.solveMeFirst(a, b));
   }
  
   @Test
   public void testAEquals0() {
	int a = 0;
	int b = 2;
	assertEquals(2, solveMeFirst.solveMeFirst(a, b));
   }
   
   @Test
   public void testBEquals0() {
	int a = 3;
	int b = 0;
	assertEquals(3, solveMeFirst.solveMeFirst(a, b));
   }
}     




   


