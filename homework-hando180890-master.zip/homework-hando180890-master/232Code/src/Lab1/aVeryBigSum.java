package Lab1;

import java.io.IOException;
import org.junit.Test;

import static org.junit.Assert.*;
import java.util.Scanner;
   
public class aVeryBigSum {

	// Complete the aVeryBigSum function below.
public static long compaVeryBigSum(long[] ar) {
		long sum = 0;
		for (int i = 0; i < ar.length; i++) {
			sum = sum + ar[i];
		}
		return sum;    

	}  

	private static final Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) throws IOException {

		int arCount = scanner.nextInt();
		scanner.nextLine();
		long[] ar = new long[arCount];
		String[] arItems = scanner.nextLine().split(" ");
		for (int i = 0; i < arCount; i++) {
			long arItem = Long.parseLong(arItems[i]);
			ar[i] = arItem;
		}
		long result = compaVeryBigSum(ar);
		System.out.println(String.valueOf(result));
		scanner.close();
	}
	
	@Test
    public void testNothing() {
	int a = 3;
	int b = 2;
	assertEquals(5, 5);
    }
	
	@Test
	public void testCorrect() {
		long[] ar = new long[5];
		ar[0]=1000000001;
		ar[1]=1000000002;
		ar[2]=1000000003;
		ar[3]=1000000004;
		ar[4]=1000000005;
		assertEquals(5000000015L, aVeryBigSum.compaVeryBigSum(ar));
	}
	
	@Test
	public void testNegative() {
		long[] ar = new long[5];
		ar[0]=-1000000001;
		ar[1]=1000000002;
		ar[2]=1000000003;
		ar[3]=1000000004;
		ar[4]=1000000005;
		assertEquals(3000000013L, aVeryBigSum.compaVeryBigSum(ar));
	}    
	
	@Test   
	public void testCon0() {
		long[] ar = new long[5];
		ar[0]=0;
		ar[1]=1000000002;
		ar[2]=1000000003;
		ar[3]=1000000004;
		ar[4]=1000000005;
		assertEquals(4000000014L, aVeryBigSum.compaVeryBigSum(ar));
	}
	
	@Test
	public void testDub() {
		long[] ar = new long[5];
		ar[0]=1000000002;
		ar[1]=1000000002;
		ar[2]=1000000003;
		ar[3]=1000000004;
		ar[4]=1000000005;
		assertEquals(5000000016L, aVeryBigSum.compaVeryBigSum(ar));
	}
	
}

  
