package Lab1;

import java.util.Scanner;

public class IOBISS {

	public static void main(String[] args) {
		/*
		 * Enter your code here. Read input from STDIN. Print output to STDOUT. Your
		 * class should be named Solution.
		 */
		Scanner sc = new Scanner(System.in);
		String[] str = null;
		if (sc.hasNextLine()) {
			str = sc.nextLine().trim().split(" ");
		}
		
		int[] data = new int[str.length];
		for (int i = 0; i < str.length; i++) {
			data[i] = Integer.parseInt(str[i]);
		}

		int resutlt = iobiss(data);
		System.out.println(String.valueOf(resutlt));
		sc.close();
	}

	private static int iobiss(int[] data) {
		// TODO Auto-generated method stub
		return iobissHelper(data, 0, -1);
	}

	private static int iobissHelper(int[] data, int curIndex, int last) {
		// TODO Auto-generated method stub
		if (curIndex == data.length) {
			return 0;
		} else {
			int include = 0;
			if (data[curIndex] > last) {
				System.out.println("CHECK A: "+ "(data, "+ curIndex+"+"+1 +" "+ data[curIndex]+")");
				include = 1 + iobissHelper(data, curIndex + 1, data[curIndex]);   
			}
			System.out.println("CHECK B: "+ "(data, "+ curIndex+"+"+1 + " "+ last+")");
			int exclude = iobissHelper(data, curIndex + 1, last);
			return Math.max(include, exclude);
		}
	}
}
