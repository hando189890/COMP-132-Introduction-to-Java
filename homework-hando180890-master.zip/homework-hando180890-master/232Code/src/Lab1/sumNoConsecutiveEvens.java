package Lab1;

import java.util.Scanner;

public class sumNoConsecutiveEvens {
	
	public static void main(String[] args) {
		/*
		 * Enter your code here. Read input from STDIN. Print output to STDOUT. Your
		 * class should be named Solution.
		 */
		Scanner sc = new Scanner(System.in);
		String[] str = null;
		if (sc.hasNextLine()) {
			str = sc.nextLine().trim().split(" ");
		}
		int[] data = new int[str.length];
		for (int i = 0; i < str.length; i++) {
			data[i] = Integer.parseInt(str[i]);
		}

		boolean resutlt = sumNoConsecutiveEvens(data, 6);
		System.out.println(String.valueOf(resutlt));
		sc.close();
	}
	
	public static boolean sumNoConsecutiveEvens(int[] vals, int targetSum) {
		return sumNoConsecutiveEvensHelper(vals, targetSum, 0, 0 ,false);
	}

	private static boolean sumNoConsecutiveEvensHelper(int[] vals, int targetSum, int curSum, int curIndex, boolean prevWasEven) {
		if(curIndex == vals.length) {
			return curSum == targetSum;
		}
		boolean take = false;
		if(vals[curIndex]%2 == 1) {
			System.out.println("( " + "vals, " +"11, "+curSum + "+" + vals[curIndex]+", "+ curIndex+ "+" +1 + ", "+ "false");
			take = sumNoConsecutiveEvensHelper(vals, targetSum, curSum+vals[curIndex], curIndex+1, false);	
		}else if(!prevWasEven) {
			System.out.println("( " + "vals, " +"11, "+curSum+ "+" +vals[curIndex]+", "+ curIndex+ "+" +1 + ", "+ "true");
			take = sumNoConsecutiveEvensHelper(vals, targetSum, curSum+vals[curIndex], curIndex+1, true);
		}
		System.out.println("Leave: ( " + "vals, " +"11, "+curSum+ "+" +vals[curIndex]+", "+ curIndex+ "+" +1 + ", "+ prevWasEven);
		boolean leave = sumNoConsecutiveEvensHelper(vals, targetSum, curSum, curIndex+1, prevWasEven);
		return take || leave ;
	}
	

}
