package Lab1;
import java.util.Arrays;
import org.junit.Test;

import static org.junit.Assert.*;
import java.io.*;
import java.lang.reflect.Array;
import java.util.*;
import org.junit.Test;

import static org.junit.Assert.*;

public class rangeFinder {

	public static int comprangeFinder(int[] ar) {
		Arrays.sort(ar);
		System.out.println("ar[0]" + ar[0]);
		System.out.println("ar[m]" + ar[ar.length-1]);
		int range = ar[ar.length - 1] - ar[0];
		return range;

	}
   
	public static void main(String[] args) {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
    	Scanner sc =new Scanner(System.in);	
		String[] str=null;
		if(sc.hasNextLine()){
			str=sc.nextLine().trim().split(" "); 
		}  
		int[] data=new int[str.length];
		for(int i=0;i<str.length;i++)
		{
			data[i]=Integer.parseInt(str[i]);
		}
		
		for(int i=0;i<str.length;i++)
		{
			System.out.println("check :" + data[i]);
		}
		int range = comprangeFinder(data);
 	    System.out.println(String.valueOf(range));
        sc.close();
	}
	
	
	@Test
	public void testsort() {
		int[] ar = new int[5];
		ar[0]=1;
		ar[1]=2;
		ar[2]=3;
		ar[3]=4;
		ar[4]=5;
		assertEquals(4,rangeFinder.comprangeFinder(ar));
	}
	
	@Test
	public void testNotsort() {
		int[] ar = new int[5];
		ar[0]=1;
		ar[1]=3;
		ar[2]=5;
		ar[3]=4;
		ar[4]=2;
		assertEquals(4,rangeFinder.comprangeFinder(ar));
	}   
	
	 
	@Test
	public void testMix() {
		int[] ar = new int[5];
		ar[0]=1;
		ar[1]=-3;
		ar[2]=5;
		ar[3]=-4;
		ar[4]=2;
		assertEquals(9,rangeFinder.comprangeFinder(ar));
	}  
	
	@Test
	public void testTwo() {
		int[] ar = new int[2];
		ar[0]=3;   
		ar[1]=1;
		assertEquals(2,rangeFinder.comprangeFinder(ar));
	}  
	
	@Test
	public void test0s() {
		int[] ar = new int[4];
		ar[0]=3;
		ar[1]=0;
		ar[2]=5;
		ar[3]=0;
		assertEquals(5,rangeFinder.comprangeFinder(ar));
	}
	
	@Test
	public void testDubs() {
		int[] ar = new int[4];
		ar[0]=3;    
		ar[1]=1;  
		ar[2]=5;
		ar[3]=1;
		assertEquals(4,rangeFinder.comprangeFinder(ar));
	}
	
	
}
		