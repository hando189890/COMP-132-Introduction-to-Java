package Lab1;

import java.util.ArrayList;
import org.junit.Test;

import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.Scanner;

public class MeanofMeans {

	public static double computeMeanOfMeans(double[][] data) {
		double[] sum = new double[data.length];
		double[] avr = new double[data.length];
		double count = 0;
		for (int i = 0; i < data.length; i++) {
			for (int j = 0; j < data[i].length; j++) {
				if (data[i][j] != 0) {
				sum[i] = sum[i] + data[i][j];
		  		System.out.println(sum[i]);
				}
			}  
		}
		for (int n = 0; n < sum.length; n++) {   
			avr[n] = sum[n]/data[n].length;
			System.out.println("avr" + avr);
		}
		for (int m = 0; m < avr.length; m++) {
			count = count + avr[m]; 
			System.out.println("avr" + avr);
		}
		count = count /avr.length;
		return count;

	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<String> lines = new ArrayList<>();
		boolean done = false;
		while (!done) {
			String line = sc.nextLine();
			if (line.equals("-1")) {
				done = true;
			} else {
				lines.add(line);
			}
		}
		double[][] data = new double[lines.size()][];
		for (int i = 0; i < lines.size(); i++) {
			System.out.println(i + " " + lines.get(i));
			String[] numStrings = lines.get(i).split(",");
			System.out.println(Arrays.toString(numStrings));
			double[] nums = new double[numStrings.length];
			for (int j = 0; j < nums.length; ++j) {
				nums[j] = Double.parseDouble(numStrings[j]);
			}
			data[i] = nums;
		}
		for (int i = 0; i < data.length; i++) {
			for (int j = 0; j < data[i].length; j++) {
				System.out.println(data[i][j]);
			}
		}
		double results = computeMeanOfMeans(data);
		System.out.println(String.format("%.2f", results));
		sc.close();
	}
	
	@Test
	public void testCase1() {
		double[][] data = new double[1][1];
		data[0][0]=1.2;
		assertEquals(1.2, MeanofMeans.computeMeanOfMeans(data),.1);
	}
	
	@Test
	public void testCase2() {
		double[][] data = new double[2][4];
		data[0][0]=2.1;
		data[0][1]=2.2;
		data[0][2]=2.3;
		data[0][3]=2.2;
		data[1][0]=2.1;
		data[1][1]=2.3;
		data[1][2]=2.2;   
		data[1][3]=2.4;
		assertEquals(2.24, MeanofMeans.computeMeanOfMeans(data),.1);
	}
	   
	@Test
	public void testCase3() {
		double[][] data = new double[2][];
		double[] s1 = new double[4];
		double[] s2 = new double[3];
		s1[0]=1.2;
		s1[1]=2.3;
		s1[2]=3.4;
		s1[3]=4.5;
		s2[0]=2.4;
		s2[1]=3.5;
		s2[2]=4.6;
		data[0] = s1;
		data[1] = s2;
		assertEquals(3.18, MeanofMeans.computeMeanOfMeans(data),.1);
	}
	
	@Test
	public void testCase4() {
		double[][] data = new double[2][4];
		data[0][0]=-2.1;
		data[0][1]=2.2;
		data[0][2]=2.3;
		data[0][3]=2.2;
		data[1][0]=2.1;
		data[1][1]=2.3;
		data[1][2]=-2.2;
		data[1][3]=2.4;
		assertEquals(1.15, MeanofMeans.computeMeanOfMeans(data),.1);
	}
	
	@Test
	public void testCase5() {
		double[][] data = new double[1][1];
		data[0][0]=0;
		assertEquals(0, MeanofMeans.computeMeanOfMeans(data),.1);
	}
	
}

