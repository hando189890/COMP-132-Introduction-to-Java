package Lab5;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Scanner;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import testbase.StdioTestBase;
               

/**
 * The huffmancoding lab
 * @author Dongbing & Zixin
 * @version 2019.12.8
 */

public class HuffmanTree implements Comparable<HuffmanTree> {
	public static int[] charinput = new int[128];

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		ArrayList<String> lines = new ArrayList<>();
		String startInfo = sc.nextLine(); // read the start information F T H M
		    
		String inputString = new String(""); //create new string to store the information
	    while (sc.hasNextLine()) {
			String curLine = sc.nextLine();
			if (curLine != null) {
				inputString = inputString + curLine;
				if (sc.hasNextLine()) { //if starting a new line in input, add \n
					inputString = inputString + "\n";
				}
			} else { 
				sc.close();
			}
		}

		if (startInfo.equals("F")) {//if F, do frequency table function
			FrequencyTable(inputString);
		} else if (startInfo.equals("T")) {//if F, do treeNode function
			HuffmanTree finalTree = treeNodes(inputString);
			finalTree.printLevelOrder();
		} else if (startInfo.equals("H")) {// if H, do huffman tree function 
			HuffmanTree finalTree = treeNodes(inputString);
			HashMap<Character, String> codes = new HashMap<Character, String>(); //create a hash map to store all sub-tree information
			huffmanCode(finalTree, "", codes);

			for (int i = 0; i < 128; i++) {//print it by following the ascii chart order
				char curChar = (char) i;
				if (codes.containsKey(curChar)) {
					System.out.println(curChar + ":" + codes.get(curChar));
				}
			}

		} else {//if M, print out in text form
			HuffmanTree finalTree = treeNodes(inputString);
			HashMap<Character, String> codes = new HashMap<Character, String>();
			huffmanCode(finalTree, "", codes);

			String output = ""; //this part function similiar with the previous condition
			for (int i = 0; i < inputString.length(); i++) {
				char curCharacter = inputString.charAt(i);
				if (codes.containsKey(curCharacter)) {
					output = output + codes.get(curCharacter);
				}
			}
			System.out.println(output);
		}

		sc.close();

	}
	
	
	/**
	 * This method find path for each subtree by recursive
	 * 
	 * @param curTree the current tree
	 * @param curCode the path to this tree
	 * @param codes the subtree hash map store the tree and its path
	 * 
	 */      

	private static void huffmanCode(HuffmanTree curTree, String curCode, HashMap<Character, String> codes) {
		if (curTree.left == null) { // if it is left, store this tree and its path to codes
			codes.put(curTree.character, curCode);
		} else { //if left, count 0, if right count 1 in its path
			huffmanCode(curTree.left, curCode + "0", codes);
			huffmanCode(curTree.right, curCode + "1", codes);
		}

	} 
	
	/**
	 * This method find frequency of each character in input
	 * @param input the information we read in our main method
	 */

	public static void FrequencyTable(String input) {
		// TODO Auto-generated method stub
		for (int i = 0; i < input.length(); i++) { // this change char to number by ascii chart
			charinput[input.charAt(i)]++; //if has this character in input, count
		}

		for (int i = 0; i < 128; i++) { //print out by convert the number to char
			if (charinput[i] != 0) {
				Character curChar = (char) (i);
				if (i != 10) {// 10 means start a new line, if it is, write \\n
					System.out.println(curChar + ":" + charinput[i]);
				} else { 
					System.out.println("\\n:" + charinput[i]);
				}
			}
		}
	}      

	/**
	 * This method make connection of all the subtrees
	 * @param input all we read in main
	 */
	public static HuffmanTree treeNodes(String input) {
		// this part similar with frequency table, after read the character and frequency, create subtrees for each chracter
		PriorityQueue<HuffmanTree> pQueue = new PriorityQueue<HuffmanTree>();
		for (int i = 0; i < input.length(); i++) {
			charinput[input.charAt(i)]++;

		}    

		for (int i = 0; i < 128; i++) {
			if (charinput[i] != 0) {
				Character curChar = (char) (i);
				HuffmanTree curTree = new HuffmanTree(charinput[i], curChar);
				pQueue.add(curTree);
			}
		}
		

		while (pQueue.size() >= 2) {
			HuffmanTree h1 = pQueue.poll();
			HuffmanTree h2 = pQueue.poll();
			pQueue.add(new HuffmanTree(h1, h2));
		}
		HuffmanTree finalTree = pQueue.poll();
		return finalTree;

	}
	
	

	HuffmanTree left, right;
	HuffmanTree parent;
	int frequency;
	char character;

	/**
	 * make a new subtree 
	 * @param frequency the frequency of this character in input
	 * @param c the character 
	 */
	public HuffmanTree(int frequency, char c) {
		this.frequency = frequency;
		character = c;
	}

	/**
	 * This make a connection of each tree
	 * 
	 * @param right the right tree
	 * @param left the left tree
	 */
	public HuffmanTree(HuffmanTree right, HuffmanTree left) {
		this.left = left;
		this.right = right;
		left.parent = this;
		right.parent = this;
		frequency = right.frequency + left.frequency;
		this.character = (char) Math.min(left.character, right.character); // tree with smaller ascii number of character is parent 

	}

	/**
	 * This method print level order of the tree
	 */
	private void printLevelOrder() {
		Queue<HuffmanTree> nodeQ = new ArrayDeque<HuffmanTree>();
		nodeQ.add(this);
		while (nodeQ.size() > 0) {
			HuffmanTree cur = nodeQ.remove();
			//the left and right below follow the rule we write in binary tree traversal
			if (cur.left != null) { 
				nodeQ.add(cur.left);
			}
			if (cur.right != null) {
				nodeQ.add(cur.right);
			}
			if ((int) cur.character != 10) { // similarly, if not start a new line, print the character
				System.out.println(cur.character + ":" + cur.frequency);
			} else {//if start a new line, do not print
				System.out.println("\\n:" + cur.frequency);
			}
		}   
	}

	@Override
	public int compareTo(HuffmanTree o) {
		if (this.frequency != o.frequency) {
			return (frequency - o.frequency);
		}
		return character - o.character;
	}

}
