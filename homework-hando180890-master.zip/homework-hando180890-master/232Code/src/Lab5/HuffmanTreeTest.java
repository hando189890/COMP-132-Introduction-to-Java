package Lab5;


import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import testbase.StdioTestBase;

public class HuffmanTreeTest extends StdioTestBase {

    @Test
    public void testFrequencyTable() {
     String input = "F\nAABBBCDDDDEE";
     String output = "A:2\nB:3\nC:1\nD:4\nE:2";
     runTest(HuffmanTree.class,input,output,"Wrong frequency table with one-line input");
    }
    
    @Test
    public void testFrequencyTable2() {
     String input = "F\nABBCDD";
     String output = "A:1\nB:2\nC:1\nD:2";	
     runTest(HuffmanTree.class,input,output,"Wrong frequency table with one-line input");
    }   
    
    @Test
    public void testFrequencyTable3() {
     String input = "F\nABBCDD\nABB\nCC";
     String output = "\\n:2\nA:2\nB:4\nC:3\nD:2";	
     runTest(HuffmanTree.class,input,output,"Wrong frequency table with one-line input");
    }
    

    @Test
    public void testFrequencyTableMultipleLines() {
     String input = "F\nABB\nCCC\nDDDD";
     String output = "\\n:2\nA:1\nB:2\nC:3\nD:4";
     runTest(HuffmanTree.class,input,output,"Wrong frequency table with multiple lines of input");
    }
    
    @Test
    public void testTreeNode() {
     String input = "T\nAABBBCDDDDEE";
     String output = "A:12\nB:7\nA:5\nD:4\nB:3\nA:3\nE:2\nA:2\nC:1";
     runTest(HuffmanTree.class,input,output,"Wrong treeNode with one line");
    }
	            
  @Test
  public void testTreeNode2() {
   String input = "T\nAABCDD";
   String output = "A:6\nA:4\nD:2\nB:2\nA:2\nC:1\nB:1";
   runTest(HuffmanTree.class,input,output,"Wrong treeNode with one line");
  }
  
  @Test
  public void testTreeNodeTwoLine() {
   String input = "T\nAABCDD\nEE";
   String output = "\\n:9\n\\n:5\nA:4\n\\n:3\nE:2\nD:2\nA:2\n\\n:2\nC:1\nB:1\n\\n:1";
   runTest(HuffmanTree.class,input,output,"Wrong treeNode with one line");
  }
                         
    @Test
    public void testHuffmanTree() {
     String input = "H\nAABBBCDDDDEE";
     String output = "A:100\nB:01\nC:101\nD:00\nE:11";
     runTest(HuffmanTree.class,input,output,"Wrong treeNode with one line");
    }
	  @Test
    public void testHuffmanTreeTwolines() {
     String input = "H\nAABBC\nCD";
     String output = ":111\nA:10\nB:01\nC:00\nD:110";
     runTest(HuffmanTree.class,input,output,"Wrong treeNode with one line");
    }  
               
    @Test
    public void testHuffmanText() {
     String input = "M\nAABBBCDDDDEE";
     String output = "100100010101101000000001111";
     runTest(HuffmanTree.class,input,output, "Wrong input with M");
    }
    
    @Test
    public void testHuffmanText2() {
     String input = "M\nAABBBCDDD\n456";
     String output = "0000001010101110101011101110000110010\n";
     runTest(HuffmanTree.class,input,output, "Wrong input with M");
    }
      
}