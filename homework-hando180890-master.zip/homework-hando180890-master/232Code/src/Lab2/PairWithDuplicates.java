package Lab2;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.junit.Test;

import Lab1.MeanofMeans;

public class PairWithDuplicates {

	/**
	 * The first method use the double for loop which use to check the result
	 * 
	 * @param arr  the array to be searched
	 * @param size the size of array
	 * @param dif  the difference that we need to calculate
	 * @return count the number that satisfy
	 */

	public static long countPairSlow(long[] arr, long size, long dif) {
	    // create a local variable to store the number of satisfy pair
		long count = 0;
	    //outside for loop is used to find first value and second for loop is used to find pair
		for (int index = 0; index < arr.length; index++) {
			for (int j = index+1; j < arr.length; j++) {
	            // if statement to look for the work pair and add to count
				if (arr[j] - arr[index] == dif||arr[index] - arr[j] == dif) {
					count++;
				}
			}
		}
		return count;
	}

	/**
	 * The method use hashmap to find pair
	 * 
	 * @param intList the array to be searched
	 * @param size    the size of array
	 * @param dif     the difference that we need to calculate
	 * @return count the number that satisfy
	 */

	public static long countPair(long[] intList, long size, long difference) {
		//create a long data type to store number of pairs
		//create a hash map to store the array of numbers 
		long output = 0;
		Map<Long, Long> map = new HashMap<Long, Long>();
		//store the number from array to hashmap 
		//each integer has correspondence number indicating the number of this integer in the array
		for (int i = 0; i < intList.length; i++) {
			if (!map.containsKey(intList[i])) {
				map.put(intList[i], (long) 1);
				System.out.println("Check1");
			} else {
				long value =  map.get(intList[i]) + 1;
				map.put(intList[i],  value);
				System.out.println("Check2");
			}
		}

		System.out.println("size" + size);
		System.out.println("dif" + difference);
		
		// the special case that the difference is 0
        if(difference ==0) {
        	for (long integer : intList) {
        		if(map.containsKey(integer)) {
        			output = output+map.get(integer)-1;
        		}
        	}
        	return output/2;
        }
        
        // create a possible1 and possible2 represent the possible pair in array
		for (long indexInt : intList) {
			long possible1 = indexInt + difference;
			long possible2 = indexInt - difference;
			System.out.println("Check 3  " + possible1 + " _  " + possible2);
			
			//check is the pair in the hash? if in the hash, how many number of this integer?
			if (map.containsKey(possible1)) {
				output = output + map.get(possible1);
				System.out.println("Find poosible1: " + indexInt);
			}
			if (map.containsKey(possible2)) {
				output = output + map.get(possible2);
				System.out.println("Find poosible2: " + indexInt);
			}
		}

		return output / 2;
	}

	public static void main(String[] args) {
		// create a scanner and system in 2 lines
		Scanner sc = new Scanner(System.in);
		ArrayList<String> lines = new ArrayList<>();
		String line1 = sc.nextLine();
		lines.add(line1);
		String line2 = sc.nextLine();
		lines.add(line2);

		// separate the first line and find the size and difference
		String[] numStrings = lines.get(0).split(" ");
		long size = Long.parseLong(numStrings[0]);
		long dif = Long.parseLong(numStrings[1]);

		// create a array that storage the numbers in the second line which use to find
		// pair

		// ArrayList<Integer> data = new ArrayList<Integer>();
		long[] data = new long[(int) size];
		String[] numberS = lines.get(1).split(" ");
		for (long j = 0; j < size; ++j) {
			data[(int) j] = Integer.parseInt(numberS[(int) j]);
		}

		// find how many pair that satisfy
		long results = countPair(data, size, dif);
		System.out.println(String.valueOf(results));
		sc.close();

	}

	@Test
	public void testCaseWith0diff() {
		long size = 5;
		long dif = 0;
		long[] line = new long[(int) size];
		line[0] = 1;
		line[1] = 1;
		line[2] = 1;
		line[3] = 3;
		line[4] = 1;
		assertEquals(6, PairWithDuplicates.countPairSlow(line, size, dif));
		assertEquals(6, PairWithDuplicates.countPair(line, size, dif));
	}

	@Test
	public void testCaseRequiedOne() {
		long size = 5;
		long dif = 2;
		long[] line = new long[(int) size];
		line[0] = 1;
		line[1] = 5;
		line[2] = 3;
		line[3] = 4;
		line[4] = 2;
		assertEquals(3, PairWithDuplicates.countPairSlow(line, size, dif));
		assertEquals(3, PairWithDuplicates.countPair(line, size, dif));
	}

	@Test
	public void testCaseRequiedTwo() {
		long size = 10;
		long dif = 1;
		long[] line = new long[(int) size];
		line[0] = 2326;
		line[1] = 530;
		line[2] = 163;
		line[3] = 718;
		line[4] = 1024;
		line[5] = 1912;
		line[6] = 635;
		line[7] = 2254;
		line[8] = 2181;
		line[9] = 1793;
		assertEquals(0, PairWithDuplicates.countPairSlow(line, size, dif));
		assertEquals(0, PairWithDuplicates.countPair(line, size, dif));
	}

	@Test
	public void testCaseSorted() {
		long size = 10;
		long dif = 3;
		long[] line = new long[(int) size];
		line[0] = 0;
		line[1] = 3;
		line[2] = 5;
		line[3] = 7;
		line[4] = 10;
		line[5] = 14;
		line[6] = 15;
		line[7] = 17;
		line[8] = 20;
		line[9] = 21;
		assertEquals(4, PairWithDuplicates.countPairSlow(line, size, dif));
		assertEquals(4, PairWithDuplicates.countPair(line, size, dif));
	}

	@Test
	public void testNegative() {
		long size = 5;
		long dif = 3;
		long[] line = new long[(int) size];
		line[0] = 1;
		line[1] = 3;
		line[2] = 5;
		line[3] = -2;
		line[4] = 10;
		assertEquals(1, PairWithDuplicates.countPairSlow(line, size, dif));
		assertEquals(1, PairWithDuplicates.countPair(line, size, dif));
	}

}
