package Lab3;

import java.util.ArrayList;
import java.util.Scanner;

import org.junit.Test;
import static org.junit.Assert.*;

public class mazeSolver {

	public char[][] maze;
	public static int startR;
	public static int startC;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<String> lines = new ArrayList<>();
		String line1 = sc.nextLine();
		String[] paraStrings = line1.split(",");

		// find size of the maze
		int row = Integer.parseInt(paraStrings[0]);
		int column = Integer.parseInt(paraStrings[1]);

		// store the maze to a 2d array
		char[][] maze = new char[row][column];
		for (int i = 0; i < row; i++) {
			String line = sc.nextLine();
			lines.add(line);
		}

		for (int i = 0; i < row; i++) {
			for (int j = 0; j < column; j++) {
				maze[i][j] = lines.get(i).charAt(j);
			}
		}

		boolean result = findPath(maze);
		if (result) {
			maze[startR][startC] = 'S';
			printMaze(maze);
		} else {
			System.out.println("No Solution!");
		}

		sc.close();

	}

	public static boolean findPath(char[][] maze) {
		for (int i = 0; i < maze.length; i++) {
			for (int j = 0; j < maze[i].length; j++) {
				if (maze[i][j] == 'S') {
					startR = i;
					startC = j;
				}
			}
		}
		maze[startR][startC] = ' ';
		return findPath(maze, startR, startC);
	}

	private static boolean findPath(char[][] maze, int row, int col) {
		// check if outside of the maze
		if (row < 0 || row >= maze.length || col < 0 || col >= maze[0].length || maze.length > 15 || maze[0].length > 15
				|| maze.length < 1 || maze[0].length < 1)
			return false;
		if (maze[row][col] == 'E') {
			return true; // found a path!
		}
		// cannot go this way
		if (maze[row][col] == 'X' || maze[row][col] == '.')
			return false;
		maze[row][col] = '.';
		// if there is a valid direction, try this direction, assign dot
		if (findPath(maze, row - 1, col)) {
			return true;
		}
		if (findPath(maze, row + 1, col)) {
			return true;
		}
		if (findPath(maze, row, col - 1)) {
			return true;
		}
		if (findPath(maze, row, col + 1)) {
			return true;
		}
		maze[row][col] = ' ';
		return false;
	}

	public static void printMaze(char[][] maze) {
		String[] mazeRows = new String[maze.length];
		for (int i = 0; i < maze.length; i++) {
			mazeRows[i] = "";
			for (int j = 0; j < maze[0].length; j++) {
				mazeRows[i] = mazeRows[i] + maze[i][j];
			}
			System.out.println(mazeRows[i]);
		}
	}

	
	
	
	
	
	@Test
	public void test2x2() {
		assertEquals("wrong answer!", true, findPath(new char[][] { { 'S', ' ' }, { ' ', 'E' } }));
	}

	@Test
	public void test2x2NoPath() {
		assertEquals("wrong answer!", false, findPath(new char[][] { { 'S', 'X' }, { 'X', 'E' } }));
	}

	@Test
	public void testNoTurns() {
		assertEquals("wrong answer for no-turn maze", true,
				findPath(new char[][] { { 'X', 'S', 'X' }, { 'X', ' ', 'X' }, { 'X', 'E', 'X' } }));
	}

	@Test
	public void testOneTurn() {
		assertEquals("wrong answer for no-turn maze", true, findPath(new char[][] { { 'X', 'S', 'X', 'X' },
				{ 'X', ' ', ' ', 'X' }, { 'X', ' ', ' ', 'X' }, { 'X', 'X', 'E', 'X' } }));
	}

	@Test
	public void testTwoTurns() {
		assertEquals("wrong answer for no-turn maze", true, findPath(new char[][] { { 'X', 'S', 'X', 'X' },
				{ 'X', ' ', ' ', 'X' }, { 'X', 'X', ' ', 'X' }, { 'X', 'X', 'E', 'X' } }));
	}

	@Test
	public void testNoPath() {
		assertEquals("wrong answer for no-turn maze", false, findPath(new char[][] { { 'X', 'S', 'X', 'X' },
				{ 'X', ' ', ' ', 'X' }, { 'X', ' ', 'X', 'X' }, { 'X', 'X', 'E', 'X' } }));
	}

	@Test
	public void testTooBig() {
		assertEquals("the maze is too big", false,
				findPath(new char[][] {
						{ 'X', 'S', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X' },
						{ 'X', ' ', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X' },
						{ 'X', ' ', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X' },
						{ 'X', ' ', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X' },
						{ 'X', ' ', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X' },
						{ 'X', ' ', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X' },
						{ 'X', ' ', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X' },
						{ 'X', ' ', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X' },
						{ 'X', ' ', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X' },
						{ 'X', ' ', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X' },
						{ 'X', ' ', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X' },
						{ 'X', ' ', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X' },
						{ 'X', ' ', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X' },
						{ 'X', ' ', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X' },
						{ 'X', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' },
						{ 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'X', 'E', 'X' } }));
	}

}

//package Lab3;
//
//import static org.junit.Assert.assertEquals;
//
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Scanner;
//
//import org.junit.Test;
//
//import Lab2.PairWithDuplicates;
//
//
///**
// * This lab is used to find a workable path in a maze. 
// * The correct path should be marked with "."
// * IF there is not path, print out 'No Solution!'
// * This lab can work with a partner so it contributes by two students
// * 
// * @author Dongbing Han & Zixin Yin
// * @version 2019.10.10
// */
//
//
//public class mazeSolver {
//
//	public static void main(String[] args) {
//		// create a scanner that used to get input
//		Scanner sc = new Scanner(System.in);
//		// the first line contains number of rows and number of cols
//		String nums = sc.nextLine();
//		String[] parts = nums.split(",");
//		int numRows = Integer.parseInt(parts[0]);
//		int numCols = Integer.parseInt(parts[1]);
//
//		// create a 2d array to store input
//		char[][] maze = new char[numRows][numCols];
//		int initRow = 0;
//		int initCol = 0;
//
//		// find the start point in this 2d array
//		for (int i = 0; i < numRows; i++) {
//			String curRow = sc.nextLine();
//			for (int j = 0; j < numCols; j++) {
//				maze[i][j] = curRow.charAt(j);
//				if (maze[i][j] == 'S') {
//					initRow = i;
//					initCol = j;
//				}
//			}
//		}
//
//		boolean solution = findSolution(maze, initRow, initCol, numRows, numCols);
//	   // boolean solution = solve(maze, initRow, initCol);
//		//boolean solution = mazeSolver(maze, initRow, initCol, numRows, numCols); 
//		maze[initRow][initCol] = 'S';
//
//		// print out the solution
//		if (solution == true) {
//			for (int i = 0; i < numRows; i++) {
//				for (int j = 0; j < numCols; j++) {
//					if (j == numCols - 1) { // check is it the last element in this row
//						System.out.println(maze[i][j]);
//					} else {
//						System.out.print(maze[i][j]);
//					}
//				}
//			}
//		} else {
//			System.out.println("No Solution!");
//		}
//
//		sc.close();
//  }
//
//
//	/**
//	 * Search through the maze and find a solution Path from start to end The
//	 * correct path should marked with "."
//	 * 
//	 * @param maze,     the 2d array which is the maze to search for solution
//	 * @param initRow   row where S is
//	 * @param initCol   col where S is
//	 * @param numRows   number of rows in the maze
//	 * @param numCols   number of cols in the maze
//	 * @return whether or not the maze has a solution
//	 */
//	public static boolean findSolution(char[][] maze, int initRow, int initCol, int numRows, int numCols) {
//		// first find the weather the initial element or current element is on correct path
//		boolean solved = false;
//		char curElement = maze[initRow][initCol];
//		if (curElement == 'E') {
//			solved = true;
//			return true;
//		} else if (curElement == 'X') {
//			return false;
//		} else if (curElement == '.') {
//			return false;
//		}
//		
//		maze[initRow][initCol] = '.'; // mark before trying the path
//		
//		//after label the element find the next step which can have four potential direction
//		if (initRow - 1 >= 0) {
//			if (findSolution(maze, initRow - 1, initCol, numRows, numCols) == true && !solved) { // try up
//				return true;
//			}
//		}
//		if (initRow + 1 < numRows) {
//			if (findSolution(maze, initRow + 1, initCol, numRows, numCols) && !solved) { // try down
//				return true;
//			}
//		}
//		if (initCol - 1 >= 0) {
//			if (findSolution(maze, initRow, initCol - 1, numRows, numCols) == true && !solved) { // try left
//				return true;
//			}
//		}
//		if (initCol + 1 < numCols) {
//			if (findSolution(maze, initRow, initCol + 1, numRows, numCols) == true && !solved) { // try right
//				return true;
//			}
//		}
//		maze[initRow][initCol] = ' '; // isn't on the path, remove the marker
//		return false; // no solution was found
//	}
//
//	
//	
//	/**
//	 * This method is used for test case function as a part of main method
//	 * It has the seem parameter as findSolution method
//	 * 
//	 * @param maze,     the 2d array which is the maze to search for solution
//	 * @param initRow   row where S is
//	 * @param initCol   col where S is
//	 * @param numRows   number of rows in the maze
//	 * @param numCols   number of cols in the maze
//	 */
//	public static void testCasePrint(char[][] maze, int initRow, int initCol, int numRows, int numCols) {
//		boolean solution = findSolution(maze, initRow, initCol, numRows, numCols);
//		if (solution == true) {
//			for (int i = 0; i < numRows; i++) {
//				for (int j = 0; j < numCols; j++) {
//					if (j == numCols - 1) { // check is it the last element in this row
//						System.out.println(maze[i][j]);
//					} else {
//						System.out.print(maze[i][j]);
//					}
//				}
//			}
//		} else {
//			System.out.println("No Solution!");
//		}
//	}
//	
//	
//
//	@Test
//	public void testCorrect() {
//		int row = 5;
//		int col = 5;
//		char[][] maze = new char[5][5];
//		maze[0][0] = 'X';
//		maze[0][1] = 'S';
//		maze[0][2] = 'X';
//		maze[0][3] = 'X';
//		maze[0][4] = 'X';
//
//		maze[1][0] = 'X';
//		maze[1][1] = ' ';
//		maze[1][2] = 'X';
//		maze[1][3] = ' ';
//		maze[1][4] = 'X';
//
//		maze[2][0] = 'X';
//		maze[2][1] = ' ';
//		maze[2][2] = ' ';
//		maze[2][3] = ' ';
//		maze[2][4] = 'X';
//
//		maze[3][0] = 'X';
//		maze[3][1] = ' ';
//		maze[3][2] = 'X';
//		maze[3][3] = ' ';
//		maze[3][4] = 'X';
//
//		maze[4][0] = 'X';
//		maze[4][1] = 'X';
//		maze[4][2] = 'X';
//		maze[4][3] = 'E';
//		maze[4][4] = 'X';
//
//		assertEquals(true, mazeSolver.findSolution(maze, 0, 1, row, col));
//		mazeSolver.testCasePrint(maze, 0, 1, 5, 5);
//	}
//
//	@Test
//	public void testWrong() {
//		int row = 5;
//		int col = 5;
//		char[][] maze = new char[5][5];
//		maze[0][0] = 'X';
//		maze[0][1] = 'S';
//		maze[0][2] = 'X';
//		maze[0][3] = 'X';
//		maze[0][4] = 'X';
//
//		maze[1][0] = 'X';
//		maze[1][1] = ' ';
//		maze[1][2] = ' ';
//		maze[1][3] = ' ';
//		maze[1][4] = 'X';
//
//		maze[2][0] = 'X';
//		maze[2][1] = ' ';
//		maze[2][2] = 'X';
//		maze[2][3] = 'X';
//		maze[2][4] = 'X';
//
//		maze[3][0] = 'X';
//		maze[3][1] = ' ';
//		maze[3][2] = 'X';
//		maze[3][3] = ' ';    
//		maze[3][4] = 'X';
//
//		maze[3][0] = 'X';
//		maze[3][1] = 'X';
//		maze[3][2] = 'X';
//		maze[3][3] = 'E';
//		maze[3][4] = 'X';
//
//		assertEquals(false, mazeSolver.findSolution(maze, 0, 1, row, col));
//		mazeSolver.testCasePrint(maze, 0, 1, row, col);
//	}
//}
//
//
//
//
