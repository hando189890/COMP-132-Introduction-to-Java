package hw05;

import java.util.NoSuchElementException;

import hw05.CS232LinkedBinaryTree.BTNode;

/**
 * Linked implementation of a binary search tree. The binary search tree
 * inherits the methods from the binary tree. The add and remove methods must
 * must be overridden so that they maintain the BST Property. The contains, get
 * and set methods are overridden to improve their performance by taking
 * advantage of the BST property. The inherited size and traversal methods work
 * well as they are.
 * 
 * @author Grant Braught
 * @author Dickinson College
 * @version March 10, 2016
 */
public class CS232LinkedBinarySearchTree<K extends Comparable<K>, V> extends CS232LinkedBinaryTree<K, V> {

	/*
	 * NOTE: We inherit the size and root fields, and the BTNode class from the
	 * LinkedBinaryTree class because they were declared as protected in that class.
	 */

	/**
	 * Construct an empty binary search tree.
	 */
	public CS232LinkedBinarySearchTree() {
		super();
	}

	/**
	 * Construct a binary search tree with a single node at the root.
	 * 
	 * @param key   the key for the root.
	 * @param value the value for the root.
	 */
	public CS232LinkedBinarySearchTree(K key, V value) {
		super(key, value);
	}

	/**
	 * Construct a binary search tree using the provided keys and values. The
	 * key,value pairs are inserted into the tree in level order. If the resulting
	 * tree does not satisfy the BST Property, then an IllegalArgumentException is
	 * thrown.
	 * 
	 * @param keys   the keys.
	 * @param values the values.
	 * @throws IllegalArgumentException if the keys and values do not have the same
	 *                                  length, the keys or the values are empty, or
	 *                                  the keys are not specified in an order that
	 *                                  results in a valid binary search tree.
	 */
	public CS232LinkedBinarySearchTree(K[] keys, V[] values) {
		super(keys, values);

		if (!checkBSTProperty()) {
			throw new IllegalArgumentException("Key, Value pairs did not satisfy BST property.");
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean contains(K key) {
		//return containsHelper(root, key);
		return getNode(root, key) != null;
	}

	/*
	 * Recursive helper method that checks if the key can be found in the subtree
	 * rooted at subTreeRoot.
	 */
//	private boolean containsHelper(BTNode<K, V> subTreeRoot, K key) {
//		if (subTreeRoot == null) {
//			return false; // off the tree.
//		} else if (subTreeRoot.key.equals(key)) {
//			return true; // found it.
//		} else if (key.compareTo(subTreeRoot.key) < 0) {
//			/*
//			 * The key we are looking for is less than the key at the subTreeRoot so if it
//			 * is in the tree it will be in the left subtree.
//			 */
//			return containsHelper(subTreeRoot.left, key);
//		} else {
//			/*
//			 * The key we are looking for is greater than or equal to the key at the
//			 * subTreeRoot so if it is in the tree it will be in the right subtree.
//			 */
//			return containsHelper(subTreeRoot.right, key);
//		}
//	}

	/**
	 * {@inheritDoc}
	 */
	public V get(K key) {
		// Intentionally not implemented - see homework assignment.
		// throw new UnsupportedOperationException("Not yet implemented");
		BTNode<K, V> node = getNode(root, key);
		if (node == null) {
			return null;
		} else {
			return node.value;

		}
	}

//	private BTNode<K, V> getNode(BTNode<K, V> cur, K k) {
//		if (cur.key.equals(k)) {
//			return cur;
//		}
//
//		// check which side to search
//		if (cur.key.compareTo(k) < 0) {
//			// make sure that side exists
//			if (cur.right == null) {
//				return null;
//			} else {
//				// recursive call
//				return getNode(cur.right, k);
//			}
//		} else {
//			// make sure that side exists
//			if (cur.left == null) {
//				return null;
//			} else {
//
//				// recursive call
//				return getNode(cur.left, k);
//			}
//		}
//	}
	
	private BTNode<K, V> getNode(BTNode<K, V> cur, K k) {
	if (cur.key.equals(k)) {
		return cur;
	}

	// check which side to search
	if (k.compareTo(cur.key) < 0) {
		// make sure that side exists
		if (cur.left == null) {
			return null;
		} else {
			// recursive call
			return getNode(cur.left, k);
		}
	} else {
		// make sure that side exists
		if (cur.right == null) {
			return null;
		} else {

			// recursive call
			return getNode(cur.right, k);
		}
	}
}


	/**
	 * {@inheritDoc}
	 * 
	 */
	public void set(K key, V value) {
		// Intentionally not implemented - see homework assignment.
		// throw new UnsupportedOperationException("Not yet implemented");
		BTNode<K, V> node = getNode(root, key);
		if (node == null) {
			throw new NoSuchElementException();
		}
		node.value = value;
	}

	/**
	 * {@inheritDoc}
	 */
	public void add(K key, V value) {
		BTNode<K, V> nodeToAdd = new BTNode<K, V>(key, value);

		if (size == 0) { // tree is empty!
			root = nodeToAdd;
		} else {
			addNodeToSubTree(root, nodeToAdd);
		}
		size++;
	}

	/*
	 * Add the nodeToAdd to the subtree rooted at subTreeRoot.
	 */
	private void addNodeToSubTree(BTNode<K, V> subTreeRoot, BTNode<K, V> nodeToAdd) {
		if (nodeToAdd.key.compareTo(subTreeRoot.key) < 0) {
			/*
			 * Key of the new node is less than the key at subTreeRoot so we are going to
			 * add the new node into the left sub tree.
			 */
			if (subTreeRoot.left == null) {
				/*
				 * The left subtree is empty, so make the new node the left child of the subtree
				 * root.
				 */
				subTreeRoot.left = nodeToAdd;
				nodeToAdd.parent = subTreeRoot;
			} else {
				/*
				 * The left subtree is not empty, so add the new node to that sub tree.
				 */
				addNodeToSubTree(subTreeRoot.left, nodeToAdd);
			}
		} else {
			/*
			 * The key of the new node is greater than or equal to the key at the
			 * subTreeRoot so we are going to add the new node to the right sub tree. This
			 * is exactly the complement of the approach used above.
			 */
			if (subTreeRoot.right == null) {
				subTreeRoot.right = nodeToAdd;
				nodeToAdd.parent = subTreeRoot;
			} else {
				addNodeToSubTree(subTreeRoot.right, nodeToAdd);
			}
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public V remove(K key) {
		/**
		 * Remove the node with the specified key from the tree. If the node containing
		 * the key is a leaf it is simply removed from the tree. If the node has one or
		 * more descendants, its rightmost leaf takes its place in the tree.
		 * 
		 * Note: Instead of removing the node, the key and value from the rightmost leaf
		 * are moved to the node and then that descendant leaf node is removed.
		 * 
		 * @param key the key of the node to be removed.
		 * @return the value of the removed node or null if no node is removed.
		 */
		/*
		 * First find the node to remove (ntr). If it doesn't exist we can return null
		 * If the ntr does exist, find the leftmost of right node Swap the key and value
		 */
		if (size == 0) {
			return null;
		} else {
			// ntr nodetoremove which get by get method
			// nv the value that in ntr which should be return
			BTNode<K, V> ntr = getNodeFromSubTree(root, key);
			V nv = ntr.value;
			if (ntr == null) {
				// node is not in the tree, done!
				return null;
			} else if (size == 1) {
				// node is the root and only node in the tree.
				size = 0;
				root = null;
				return nv;
			} else if (ntr.isLeaf()) {
				// if ntr is the leaf
				removeHelper(ntr, null);
			} else if (ntr.left == null) {
				// if removed node only has a left child, so that replace the removed node
				removeHelper(ntr, ntr.right);
			} else if (ntr.right == null) {
				// if removed node only has a right child, so that replace the removed node
				removeHelper(ntr, ntr.left);
			} else {
				// Find the left-most descendant of right subnode
				BTNode<K, V> noderight = findLeftMost(ntr.right);
				
//				ntr.key = noderight.key;
//				ntr.value = noderight.value;
//				noderight.parent.left = null;
				
				remove(noderight.key);
				ntr.key = noderight.key;
				ntr.value = noderight.value;
			}
			return nv;
		}
	}

	/*
	 * This method use to find left most of right sub-node
	 */
	public BTNode<K, V> findLeftMost(BTNode<K, V> node) {
		BTNode<K, V> curnode = null;
		while (node.left != null) {
			curnode = node.left;
			node = node.left;
		}
		return curnode;
	}

	/*
	 * Remove helper ntr nodetoremove which shows a node that is removed by remove
	 * method nts nodetoreplace which shows a node that will replace the position
	 * that node being removed
	 */
	private void removeHelper(BTNode<K, V> ntr, BTNode<K, V> nts) {
		if (ntr.parent == null) { // if ntr is the root
			root = nts;
		} else {
			if (ntr.parent.left == ntr) { // if ntr is the left child of subtree
				ntr.parent.left = nts;
			} else if (ntr.parent.right == ntr) { // if ntr is the right child of subtree
				ntr.parent.right = nts;
			} else {
				throw new IllegalArgumentException("A invalid child");
			}
		}
		// When a leaf node is being removed, there no node to replace in that position.
		if (nts != null) {
			nts.parent = ntr.parent;
		}
		ntr.parent = null;
		size--;
	}



	/*
	 * Helper method that verifies the BST property of this tree by traversing the
	 * tree and verifying that at each node the key of the left child is < the key
	 * of the node and that the key of the right child is >= the key of the node.
	 * This is used by the
	 */
	boolean checkBSTProperty() {
		return checkBSTPropertyHelper(root);
	}

	private boolean checkBSTPropertyHelper(BTNode<K, V> subTreeRoot) {
		if (subTreeRoot == null) {
			return true; // off tree.
		} else {
			if (leftChildOK(subTreeRoot) && rightChildOK(subTreeRoot)) {
				return checkBSTPropertyHelper(subTreeRoot.left) && checkBSTPropertyHelper(subTreeRoot.right);
			} else {
				return false;
			}
		}
	}

	private boolean leftChildOK(BTNode<K, V> node) {
		if (node.left == null) {
			return true;
		} else {
			// true if key at node is > key at left child.
			return node.key.compareTo(node.left.key) > 0;
		}
	}

	private boolean rightChildOK(BTNode<K, V> node) {
		if (node.right == null) {
			return true;
		} else {
			// true if key at node is <= key at right child.
			return node.key.compareTo(node.right.key) <= 0;
		}
	}
}
