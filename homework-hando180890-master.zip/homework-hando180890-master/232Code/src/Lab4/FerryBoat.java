package Lab4;

import static org.junit.Assert.assertEquals;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

import org.junit.Test;

public class FerryBoat {

	Queue<CarNode> left = new ArrayDeque<CarNode>();
	Queue<CarNode> right = new ArrayDeque<CarNode>();
	int length;
	int numCar;
	ArrayList<String> outputlist = new ArrayList<String>();

	public static void main(String[] args) throws Exception {
		FerryBoat myBoat = new FerryBoat();
		myBoat.readInput(new Scanner(System.in)); // read the car information
		myBoat.solveProblem(); // solve the problem
	}
    
	public void readInput(Scanner sc) {
		ArrayList<String> lines = new ArrayList<>();
		String line1 = sc.nextLine();
		String[] paraStrings = line1.split(" ");

		// find length of boat and number of cars
		length = Integer.parseInt(paraStrings[0]) * 100;
		numCar = Integer.parseInt(paraStrings[1]);
        
		// length should be 0-100 and number of car should be 0-500
		if (length > 0 && length <= 10000 && numCar >= 0 && numCar <= 500) {

			// if number of car = 0, print Day Off!
			if (numCar == 0) {
				System.out.println("Day Off!");
			} else {
				// else begin to read each car's information
				for (int i = 0; i < numCar; i++) {
					String line = sc.nextLine();
					lines.add(line);
				}
			}

			// create carNodes to store each car's information including length, plate, and
			// initial bank
			// after that split each car it into left and right queue with different staring
			// bank
			for (int i = 0; i < numCar; i++) {
				String[] carInfo = lines.get(i).split(" ");
				int carlength = Integer.parseInt(carInfo[0]);
				CarNode newcar = new CarNode(carlength, carInfo[1], carInfo[2]);
				if (newcar.startingBank.equals("left")) {
					left.add(newcar); // if the direction is left, put it in right queue
				} else {
					right.add(newcar); // if the direction is right, put it in right queue
				}
			}
		}
	}

	// when one of the queue is not empty, call solve the problem method
	// this method has a helper method solver and each time run both left and right queue
	public void solveProblem() throws Exception {
		int count = 0; // use to track each line
		while (!(left.size()==0)|| !(right.size()==0)) {
			Solver(length, left, 2 * count + 1);
			Solver(length, right, 2 * count + 2);
			count++;
		}
		for(int i=0; i<outputlist.size(); i++) {
			System.out.println(outputlist.get(i));
		}
	}

	/**
	 * The helper method for solveProblem which can print the car transport
	 * information
	 * 
	 * @param carQueue the left or the right queue of cars
	 * @param curIndex used to print the number at beginning of each line
	 * @param length   the length of ferry boat
	 * @throws Exception 
	 */
	public void Solver(int length, Queue<CarNode> cars, int count) throws Exception {
		// create a output string to store print information
		String output = new String(count + " :");
		if (cars.size()==0) { // if carQueue is not empty, print empty
			output = output + " empty";
		} else {
			int currentLength = 0;// the currentLength used to store how much is in the ferry boat
			while (!(cars.size()==0)) {
				CarNode curCar = cars.peek(); // get the first car in the queue
				if (curCar.k <= length &&  curCar.k+currentLength <= length) { 
					//the length of each car should smaller than the length of boat
					// compare the currentLength with ferry boat's length
						output = output + " " + curCar.plate;// if works, add this car's plate to the output(string)
						currentLength = currentLength + curCar.k;
						cars.poll(); // remove it after adding
					}else {
						break;// if not work, break
					}
							
					}
				}
			
		outputlist.add(output);
	}

	// create a carNode with key, value and direction
	// key a integer to store the length of each car
	// value a string to store the plate the car
	// direction a string to store the initial bank
	class CarNode {
		public int k;
		public String plate;
		public String startingBank;

		public CarNode(int key, String value, String direction) {
			this.k = key;
			this.plate = value;
			this.startingBank = direction;
		}
	}

	// THE FOLLOWING METHODS ARE USED ONLY IN THE JAVA UNIT TEST

	public int getLength() {
		return length;
	}

	public int getNumberOfCar() {
		return numCar;
	}

	public String getInof(int index) {
		return outputlist.get(index);
	}

	public void setLength(int len) {
		length = len;
	}

	public void setNumberOfcar(int num) {
		if (num == 0) {
			String string = "Day Off!";
			outputlist.add(string);
		}
		numCar = num;
	}

	public void setCarinfo(CarNode newcar) {
		if (newcar.startingBank.equals("left")) {
			left.offer(newcar);
		} else {
			right.offer(newcar);
		}
	}

	@Test
	public void test3CarsFromSmall() throws Exception {
		setLength(2000);
		setNumberOfcar(3);
		CarNode newcar1 = new CarNode(380, "ABC", "left");
		CarNode newcar2 = new CarNode(740, "DEF", "left");
		CarNode newcar3 = new CarNode(1340, "GHI", "right");
		setCarinfo(newcar1);
		setCarinfo(newcar2);
		setCarinfo(newcar3);
		solveProblem();
		assertEquals(2000, getLength());
		assertEquals(3, getNumberOfCar());
		assertEquals("1 : ABC DEF", getInof(0));
		assertEquals("2 : GHI", getInof(1));
	}

	@Test
	public void test3CarsFromBig() throws Exception {
		setLength(2000);
		setNumberOfcar(3);
		CarNode newcar1 = new CarNode(1480, "ABC", "left");
		CarNode newcar2 = new CarNode(720, "DEF", "right");
		CarNode newcar3 = new CarNode(575, "GHI", "left");
		setCarinfo(newcar1);
		setCarinfo(newcar2);
		setCarinfo(newcar3);
		solveProblem();
		assertEquals(2000, getLength());
		assertEquals(3, getNumberOfCar());
		assertEquals("1 : ABC", getInof(0));
		assertEquals("2 : DEF", getInof(1));
		assertEquals("3 : GHI", getInof(2));
		assertEquals("4 : empty", getInof(3));
	}

	@Test
	public void testEmpty() throws Exception {
		setLength(2000);
		setNumberOfcar(0);
		solveProblem();
		assertEquals(2000, getLength());
		assertEquals(0, getNumberOfCar());
		assertEquals("Day Off!", getInof(0));
	}

	@Test
	public void test6CarAlternatingOne() throws Exception {
		setLength(300);
		setNumberOfcar(6);
		CarNode newcar1 = new CarNode(200, "ABC", "left");
		CarNode newcar2 = new CarNode(200, "DEF", "left");
		CarNode newcar3 = new CarNode(200, "GHI", "left");
		CarNode newcar4 = new CarNode(200, "JKL", "right");
		CarNode newcar5 = new CarNode(200, "MNO", "right");
		CarNode newcar6 = new CarNode(200, "PQR", "right");
		setCarinfo(newcar1);
		setCarinfo(newcar2);
		setCarinfo(newcar3);
		setCarinfo(newcar4);
		setCarinfo(newcar5);
		setCarinfo(newcar6);
		solveProblem();
		assertEquals(300, getLength());
		assertEquals(6, getNumberOfCar());
		assertEquals("1 : ABC", getInof(0));
		assertEquals("2 : JKL", getInof(1));
		assertEquals("3 : DEF", getInof(2));
		assertEquals("4 : MNO", getInof(3));
		assertEquals("5 : GHI", getInof(4));
		assertEquals("6 : PQR", getInof(5));
	}

	@Test
	public void test6CarAlternatingTwo() throws Exception {
		setLength(300);
		setNumberOfcar(6);
		CarNode newcar1 = new CarNode(100, "ABC", "left");
		CarNode newcar2 = new CarNode(100, "DEF", "left");
		CarNode newcar3 = new CarNode(200, "GHI", "left");
		CarNode newcar4 = new CarNode(100, "JKL", "right");
		CarNode newcar5 = new CarNode(100, "MNO", "right");
		CarNode newcar6 = new CarNode(200, "PQR", "right");
		setCarinfo(newcar1);
		setCarinfo(newcar2);
		setCarinfo(newcar3);
		setCarinfo(newcar4);
		setCarinfo(newcar5);
		setCarinfo(newcar6);
		solveProblem();
		assertEquals(300, getLength());
		assertEquals(6, getNumberOfCar());
		assertEquals("1 : ABC DEF", getInof(0));
		assertEquals("2 : JKL MNO", getInof(1));
		assertEquals("3 : GHI", getInof(2));
		assertEquals("4 : PQR", getInof(3));
	}

	@Test
	public void testFirstCarInRight() throws Exception {
		setLength(300);
		setNumberOfcar(6);
		CarNode newcar1 = new CarNode(200, "ABC", "right");
		CarNode newcar2 = new CarNode(200, "DEF", "right");
		CarNode newcar3 = new CarNode(200, "GHI", "right");
		CarNode newcar4 = new CarNode(200, "JKL", "left");
		CarNode newcar5 = new CarNode(200, "MNO", "left");
		CarNode newcar6 = new CarNode(200, "PQR", "left");
		setCarinfo(newcar1);
		setCarinfo(newcar2);
		setCarinfo(newcar3);
		setCarinfo(newcar4);
		setCarinfo(newcar5);
		setCarinfo(newcar6);
		solveProblem();
		assertEquals(300, getLength());
		assertEquals(6, getNumberOfCar());
		assertEquals("1 : JKL", getInof(0));
		assertEquals("2 : ABC", getInof(1));
		assertEquals("3 : MNO", getInof(2));
		assertEquals("4 : DEF", getInof(3));
		assertEquals("5 : PQR", getInof(4));
		assertEquals("6 : GHI", getInof(5));
	}

	@Test
	public void testEmptyInMiddel() throws Exception {
		setLength(300);
		setNumberOfcar(2);
		CarNode newcar1 = new CarNode(200, "ABC", "left");
		CarNode newcar2 = new CarNode(200, "DEF", "left");
		setCarinfo(newcar1);
		setCarinfo(newcar2);
		solveProblem();
		assertEquals(300, getLength());
		assertEquals(2, getNumberOfCar());
		assertEquals("1 : ABC", getInof(0));
		assertEquals("2 : empty", getInof(1));
		assertEquals("3 : DEF", getInof(2));
		assertEquals("4 : empty", getInof(3));
	}

	@Test
	public void testEmptyFrist() throws Exception {
		setLength(300);
		setNumberOfcar(1);
		CarNode newcar1 = new CarNode(200, "ABC", "right");
		setCarinfo(newcar1);
		solveProblem();
		assertEquals(300, getLength());
		assertEquals(1, getNumberOfCar());
		assertEquals("1 : empty", getInof(0));
		assertEquals("2 : ABC", getInof(1));
	}

	@Test
	public void testFirstLineTwoCarSecondOne() throws Exception {
		setLength(300);
		setNumberOfcar(3);
		CarNode newcar1 = new CarNode(200, "ABC", "left");
		CarNode newcar2 = new CarNode(100, "DEF", "left");
		CarNode newcar3 = new CarNode(200, "GHI", "right");
		setCarinfo(newcar1);
		setCarinfo(newcar2);
		setCarinfo(newcar3);
		solveProblem();
		assertEquals(300, getLength());
		assertEquals(3, getNumberOfCar());
		assertEquals("1 : ABC DEF", getInof(0));
		assertEquals("2 : GHI", getInof(1));
	}

	@Test
	public void testSeoncLineTwoCarFirstOne() throws Exception {
		setLength(300);
		setNumberOfcar(3);
		CarNode newcar1 = new CarNode(200, "ABC", "right");
		CarNode newcar2 = new CarNode(100, "DEF", "right");
		CarNode newcar3 = new CarNode(200, "GHI", "left");
		setCarinfo(newcar1);
		setCarinfo(newcar2);
		setCarinfo(newcar3);
		solveProblem();
		assertEquals(300, getLength());
		assertEquals(3, getNumberOfCar());
		assertEquals("1 : GHI", getInof(0));
		assertEquals("2 : ABC DEF", getInof(1));
	}

	@Test
	public void test4carsAtOneside() throws Exception {
		setLength(300);
		setNumberOfcar(4);
		CarNode newcar1 = new CarNode(200, "ABC", "left");
		CarNode newcar2 = new CarNode(100, "DEF", "left");
		CarNode newcar3 = new CarNode(200, "GHI", "left");
		CarNode newcar4 = new CarNode(200, "MNO", "left");
		setCarinfo(newcar1);
		setCarinfo(newcar2);
		setCarinfo(newcar3);
		setCarinfo(newcar4);
		solveProblem();
		assertEquals(300, getLength());
		assertEquals(4, getNumberOfCar());
		assertEquals("1 : ABC DEF", getInof(0));
		assertEquals("2 : empty", getInof(1));
		assertEquals("3 : GHI", getInof(2));
		assertEquals("4 : empty", getInof(3));
		assertEquals("5 : MNO", getInof(4));
		assertEquals("6 : empty", getInof(5));
	}

}
