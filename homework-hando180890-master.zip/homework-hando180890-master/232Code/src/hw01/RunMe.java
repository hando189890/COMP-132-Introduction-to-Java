package hw01;

public class RunMe {
	public static void main(String[] args) {
		System.out.println("You got it!");
	}
}
  