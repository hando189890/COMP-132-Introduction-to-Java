package lab07.recursion;

/**
 * Recursive computation of x^n.
 *
 * @author (Dongbing & Zixin)
 * @version (2019.4.7)
 */
public class Exponentiation {

    /**
     * Compute the value of x^n.
     * 
     * @param x the base (non-negative integer)
     * @param n the exponent (non-negative integer)
     * @return x^n
     */
    public static long exp(int x, int n) {
        if (n == 0) {
        		return 1;
        	}else {  
        		if (n %2 != 0) {
        		   return x*exp(x, n-1);
        	    }else {
        	       return exp(x, n/2)*exp(x, n/2);
                    
        		
        	}
        }
    }
}
