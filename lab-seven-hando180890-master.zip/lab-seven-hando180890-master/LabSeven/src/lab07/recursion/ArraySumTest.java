package lab07.recursion;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ArraySumTest {
	private int[] arr;
	private int[] arry;
	private int[] arr2;
	
	@Before
	public void setUp() throws Exception {
		arr = new int[6];
		arr[0]=1;
		arr[1]=2;
		arr[2]=3;
		arr[3]=4;
		arr[4]=5;
		arr[5]=6;
		arry = new int[1];
		arry[0] = 6;  
		arr2 = new int[5];
		arr2[0]=1;
		arr2[1]=2;
		arr2[2]=3;
		arr2[3]=4;
		arr2[4]=5;
		
		
	}

	@Test
	public void testConstructorOne() {
		ArraySum a1 = new ArraySum();
		assertEquals(21, a1.arraySum(arr, 0, 5));
	}
	
	@Test
	public void testConstructorThree() {
		ArraySum a1 = new ArraySum();
		assertEquals(15, a1.arraySum(arr2, 0, 4));
	}
	
	@Test
	public void testConstructorTwo() {
		ArraySum a2 = new ArraySum();
		assertEquals(6, a2.arraySum(arry, 0, 0));
	}
}
