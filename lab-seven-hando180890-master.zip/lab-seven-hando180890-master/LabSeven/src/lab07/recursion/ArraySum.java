package lab07.recursion;

/**
 * Recursive computation of the sum of all of the elements in an array.
 * 
 * @author (Dongbing & Zixin)
 * @version (2019.4.3)
 */
public class ArraySum {

    /**
     * Compute the total of all of the elements in arr using recursion. You may
     * assume that the array contains at least 1 element (i.e. arr.length >= 1)
     * 
     * @param arr the array to sum up.
     * @return the total of all of the elements in the array.
     */    
    public static int arraySum(int[] arr, int start, int last) {
    	int sum = 0;
        if (arr.length == 1) {
        	return arr[0];
        }
        else {  
        	if (start < last) {
        		sum = +arr[start] + arr[last] +arraySum(arr, start+1, last-1);
        		
        	}else if (start == last) {
        		sum = +arr[start] +arraySum(arr, start+1, last-1);
        	}
        }
        	
        	return sum;
        	
         }
    }
  

    
    

