package lab07.recursion;

import static org.junit.Assert.*;

import org.junit.Test;

public class PyramidBoxCountTest {

	
//	@Before
//	public void setUp() throws Exception() {
//		
//	}

	@Test
	public void testConstructorOne() {
		PyramidBoxCount p = new PyramidBoxCount();
		assertEquals(2, PyramidBoxCount.computePyramidBoxes(2));
	}
	
	@Test  
	public void testConstructorTwo() {
		PyramidBoxCount p = new PyramidBoxCount();
		assertEquals(12, PyramidBoxCount.computePyramidBoxes(6));
	}

}
