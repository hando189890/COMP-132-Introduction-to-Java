package lab07.recursion;

import static org.junit.Assert.*;

import org.junit.Test;

public class ExponentiationTest {

	@Test
	public void testConstructorOne() {
		Exponentiation e1 = new Exponentiation();
		assertEquals(1, e1.exp(2, 0));
	}

	  
	@Test
	public void testConstructorTwo() {
		Exponentiation e1 = new Exponentiation();
		assertEquals(16, e1.exp(2, 4));
	}

	
	@Test
	public void testConstructorThree() {
		Exponentiation e1 = new Exponentiation();
		assertEquals(8, e1.exp(2, 3));
	}

}
