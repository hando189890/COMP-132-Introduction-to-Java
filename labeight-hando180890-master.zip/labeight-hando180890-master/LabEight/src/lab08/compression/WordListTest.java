package lab08.compression;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class WordListTest {
	
	private WordList wl;
	
	private WordIntPair w1;
	private WordIntPair w2;
	private WordIntPair w3;
	private WordIntPair w4;
	private WordIntPair w5;
	private WordIntPair w6;
	
	  
	@Before
	public void setUp() throws Exception {
		wl = new WordList();  
//		w1 = new WordIntPair("a");
//		w2 = new WordIntPair("b");
//		w2.setValue(2);
//		w3 = new WordIntPair("c");
//		w4 = new WordIntPair("a");
		
	}
  
	@Test
	public void testConstuctor() {
		assertEquals(0, wl.size());
		wl.addWord("a");
		assertEquals(1, wl.size());
	}
	
	@Test
	public void testAddWord() {
		assertEquals(0, wl.size());
		wl.addWord("a");
		wl.addWord("b");
		wl.addWord("a");
		assertEquals(2, wl.size());
	}
	
	@Test
	public void testGetIndex() {
		assertEquals(0, wl.size());
		wl.addWord("a");
		wl.addWord("b");
		wl.addWord("c");
		wl.addWord("d");
		wl.addWord("e");
		wl.addWord("f");
		wl.addWord("c");
		assertEquals(6, wl.size());
		
		assertEquals(3, wl.getIndex("d"));
	}
	
	@Test
	public void testGetWord() {
		wl.addWord("a");
		wl.addWord("b");
		wl.addWord("c");
		wl.addWord("d");
		wl.addWord("e");
		wl.addWord("f");
		wl.addWord("c");
		assertEquals(6, wl.size());
		assertEquals("d", wl.getWord(3));
	}
	
	@Test
	public void testSort() {
		wl.addWord("a");
		wl.addWord("b");
		wl.addWord("c");
		wl.addWord("b");
		wl.addWord("c");
    	wl.addWord("d");
    	wl.addWord("b");
    	wl.sortByFrequency();
		assertEquals(4, wl.size());
		assertEquals(0, wl.getIndex("b"));
		assertEquals(1, wl.getIndex("c"));
		assertEquals(2, wl.getIndex("a"));
		assertEquals(3, wl.getIndex("d"));
	}

}
