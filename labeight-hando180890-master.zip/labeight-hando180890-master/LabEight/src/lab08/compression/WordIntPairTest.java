package lab08.compression;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class WordIntPairTest {
	
	private WordIntPair w1;
	private WordIntPair w2;
	private WordIntPair w3;
	
	@Before
	public void setUp() throws Exception {
		w1 = new WordIntPair("a");
		w2 = new WordIntPair("b");  
		w2.setValue(2);
		w3 = new WordIntPair("c");
		
	}

	@Test
	public void testConstructor() {  
		assertEquals("a", w1.getWord());
		assertEquals(1, w1.getIntValue());
	}
	
	@Test
	public void testSetValue() {
		w1.setValue(3);
		assertEquals(3, w1.getIntValue());
	}
	
	@Test
	public void testCompare() {
		assertEquals(1, w1.compareTo(w2));
		assertEquals(-1, w2.compareTo(w1));
		assertEquals(0, w3.compareTo(w1));
	}

}
