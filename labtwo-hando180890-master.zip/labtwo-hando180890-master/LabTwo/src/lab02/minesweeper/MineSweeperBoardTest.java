package lab02.minesweeper;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class MineSweeperBoardTest {
	
	private MineSweeperBoard b1;
	
	@Before
    public void setUp() throws Exception {
        /*
         * Construct all of the objects being used in the test fixture here.
         */
		
	}

	
	@Test
	public void testConsturctor() {
		MineSweeperBoard b1 = new MineSweeperBoard();
		assertEquals(3, b1.getRows());
		assertEquals(4, b1.getColumns());
		assertEquals(2, b1.getNumMines());
		assertEquals(-2, b1.getCell(0, 0));
		assertEquals(-2, b1.getCell(2, 1));
		assertEquals(-1, b1.getCell(0, 1));
		
	}
	
	@Test
	public void testGetCellFalse() {
		MineSweeperBoard b1 = new MineSweeperBoard();
		assertEquals(MineSweeperBoard.INVALID_CELL, b1.getCell(-1, 0));
		assertEquals(MineSweeperBoard.INVALID_CELL, b1.getCell(8, 0));
		assertEquals(MineSweeperBoard.INVALID_CELL, b1.getCell(0, 10));
		assertEquals(MineSweeperBoard.INVALID_CELL, b1.getCell(0, -1));
	}
		
	@Test
	public void testNumAdjMineFalseRow() {
		MineSweeperBoard b1 = new MineSweeperBoard();
		
	}		

	
	@Test
	public void testNumAdjMineFalseCol() {
		MineSweeperBoard b1 = new MineSweeperBoard();
		assertEquals(0, b1.numAdjMines(0, -3));
		assertEquals(0, b1.numAdjMines(0, 8));
	}
	
	@Test
	public void testNumAdjMineTrue() {
		MineSweeperBoard b1 = new MineSweeperBoard();
		assertEquals(1, b1.numAdjMines(0, 1));
	}
	
	@Test
	public void testNumAdjMineTrue2() {
		MineSweeperBoard b1 = new MineSweeperBoard();
		b1.uncoverCell(0, 0);
		assertEquals(2, b1.numAdjMines(1, 0));
	}
	
	@Test
	public void testNumAdjMineTrue3() {
		MineSweeperBoard b1 = new MineSweeperBoard();
		assertEquals(1, b1.numAdjMines(2, 0));
	}
	@Test
	public void testNumAdjMineTrue4() {
		MineSweeperBoard b1 = new MineSweeperBoard();
		b1.flagCell(2,1);
		assertEquals(2, b1.numAdjMines(1, 1));
	}
	@Test
	public void testNumAdjMineTrue5() {
		MineSweeperBoard b1 = new MineSweeperBoard();
		assertEquals(1, b1.numAdjMines(2, 2));
	}
	
	@Test
	public void testUncoverCell() {
		MineSweeperBoard b1 = new MineSweeperBoard();
		b1.uncoverCell(0, 1);
		assertEquals(1, b1.getCell(0, 1));
	}
	
	@Test
	public void testUncoverCellMine() {
		MineSweeperBoard b1 = new MineSweeperBoard();
		b1.uncoverCell(0, 0);
		assertEquals(-5, b1.getCell(0, 0));
	}
	
	@Test
	public void testUncoverCellFlag() {
		MineSweeperBoard b1 = new MineSweeperBoard();
		b1.flagCell(0, 1);
		b1.uncoverCell(0, 1);
		assertEquals(-3, b1.getCell(0, 1));
	}
	
	@Test
	public void tesFlagCellCover() {
		MineSweeperBoard b1 = new MineSweeperBoard();
		b1.flagCell(0, 1);
		assertEquals(-3, b1.getCell(0, 1));
	}
	
	@Test
	public void testFlagCellFlag() { 
		MineSweeperBoard b1 = new MineSweeperBoard();
        b1.flagCell(0, 1);
		b1.flagCell(0, 1);
		assertEquals(-1, b1.getCell(0, 1));
	}
	
	@Test
	public void tesFlagCellMine() { 
		MineSweeperBoard b1 = new MineSweeperBoard();
		b1.flagCell(0, 0);
		assertEquals(-4, b1.getCell(0, 0));
	}
	
	@Test
	public void testFlagCellFLAGMine() { 
		MineSweeperBoard b1 = new MineSweeperBoard();
		b1.flagCell(0, 0);
		b1.flagCell(0, 0);
		assertEquals(-2, b1.getCell(0, 0));
	}
	
	@Test
	public void testUncoverAllCell() { 
		MineSweeperBoard b1 = new MineSweeperBoard();
		b1.revealBoard();
		assertEquals(-5, b1.getCell(0, 0));
		assertEquals(-5, b1.getCell(2, 1));
		assertEquals(2, b1.getCell(1, 0));
		assertEquals(0, b1.getCell(1, 3));
		assertEquals(2, b1.getCell(1, 1));
	}
	
	@Test
	public void testGameLostFalse() { 
		MineSweeperBoard b1 = new MineSweeperBoard();
		assertFalse(b1.gameLost());
		
	}
	
	@Test
	public void testGameLostTrue() { 
		MineSweeperBoard b1 = new MineSweeperBoard();
		b1.uncoverCell(0, 0);
        assertTrue(b1.gameLost());	
	}
	
	@Test
	public void testGameWonFalse() { 
		MineSweeperBoard b1 = new MineSweeperBoard();
		b1.uncoverCell(0, 1);
		b1.uncoverCell(0, 2);
		b1.uncoverCell(0, 3);
		b1.uncoverCell(1, 0);
		b1.uncoverCell(1, 1);
		b1.uncoverCell(1, 2);
		b1.uncoverCell(1, 3);
		b1.uncoverCell(2, 0);
		b1.uncoverCell(2, 2);
		b1.uncoverCell(2, 3);
        assertFalse(b1.gameWon());	
	}
	
	@Test
	public void testGameWonFalse2() { 
		MineSweeperBoard b1 = new MineSweeperBoard();
		b1.flagCell(0,1);
		b1.flagCell(0,2);
		b1.flagCell(0,3);
		b1.flagCell(1,0);
		b1.flagCell(1,1);
		b1.flagCell(1,2);
		b1.flagCell(1,3);
		b1.flagCell(2,0);
		b1.flagCell(2,2);
		b1.flagCell(2,3);
		b1.uncoverCell(0, 0);
		b1.uncoverCell(2, 1);
        assertFalse(b1.gameWon());	
	}
	
	@Test
	public void testGameWonFalse3() { 
		MineSweeperBoard b1 = new MineSweeperBoard();
		b1.uncoverCell(0, 0);
		b1.uncoverCell(2, 1);
        assertFalse(b1.gameWon());	
	}
	
	@Test
	public void testGameWonTrue() { 
		MineSweeperBoard b1 = new MineSweeperBoard();
		b1.revealBoard();
        assertTrue(b1.gameWon());	
	}
	
	@Test
	public void testSecondConsturctorLevel1() {
		MineSweeperBoard b1 = new MineSweeperBoard(MineSweeperBoard.BEGINNER_LEVEL);
		assertEquals(5, b1.getRows());
		assertEquals(10, b1.getColumns());
		assertEquals(3, b1.getNumMines());
		
	}
	
	@Test
	public void testSecondConsturctorLevel2() {
		MineSweeperBoard b1 = new MineSweeperBoard(MineSweeperBoard.INTERMEDIATE_LEVEL);
		assertEquals(10, b1.getRows());
		assertEquals(15, b1.getColumns());
		assertEquals(15, b1.getNumMines());
		
	}
	
	
	@Test
	public void testSecondConsturctorLevel3() {
		MineSweeperBoard b1 = new MineSweeperBoard(MineSweeperBoard.EXPERT_LEVEL);
		assertEquals(15, b1.getRows());
		assertEquals(20, b1.getColumns());
		assertEquals(45, b1.getNumMines());		
	}
	
	
}


