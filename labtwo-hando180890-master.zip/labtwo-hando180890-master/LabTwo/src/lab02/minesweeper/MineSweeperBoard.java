package lab02.minesweeper;

import java.util.Random;

/**
 * A MineSweeperBoard holds a representation of the contents of the playing
 * field for a Mine Sweeper game. The playing field is represented using a 2
 * dimensional array of integer values. The integer value stored in each cell of
 * the array indicates the icon which will appear in the corresponding cell of
 * the graphical user interface for the game.
 * 
 * @author Grant Braught
 * @author Tim Wahls
 * @author Dickinson College
 * @version Aug 13, 2009
 *
 * @author (Dongbing & Katya)
 * @version (2019.2.6)
 */

public class MineSweeperBoard {

	/**
	 * A constant value representing a covered cell. A covered cell is any cell
	 * which does not contains a mine, has not been flagged and has not yet been
	 * uncovered.
	 */
	public static final int COVERED_CELL = -1;

	/**
	 * A constant value representing a a cell that has not been uncovered yet but
	 * contains a mine.
	 */
	public static final int MINE = -2;

	/**
	 * A constant value representing a cell which does not contain a mine but has
	 * had a flag placed on it.
	 */
	public static final int FLAG = -3;

	/**
	 * A constant value representing a cell which contains a mine and has had a flag
	 * placed on it.
	 */
	public static final int FLAGGED_MINE = -4;

	/**
	 * A constant value representing a cell containing a mine that has been
	 * uncovered.
	 */
	public static final int UNCOVERED_MINE = -5;

	/**
	 * A constant value representing the contents of an invalid cell. This value is
	 * returned by the getCell method when an invalid cell is specified.
	 */
	public static final int INVALID_CELL = -10;

	/**
	 * A constant value representing the easiest level of play.
	 */
	public static final int BEGINNER_LEVEL = 1;

	/**
	 * A constant value representing an intermediate level of play.
	 */
	public static final int INTERMEDIATE_LEVEL = 2;

	/**
	 * A constant value representing the hardest level of play.
	 */
	public static final int EXPERT_LEVEL = 3;


	// Define a field to hold your board here, initialize it in your constructors.\

	private int[][] myboard;

	/**
	 * Construct a new fixed MineSweeperBoard for testing purposes. The board should
	 * have 3 rows and 4 columns. All cells should contain COVERED_CELL, except that
	 * locations (0, 0) and (2, 1) should contain MINE.
	 */
	public MineSweeperBoard() {
		myboard = new int[3][4];
		for (int row = 0; row < myboard.length; row++) {
			for (int col = 0; col < myboard[row].length; col++) {
				myboard[row][col] = COVERED_CELL;
			}
		}
		myboard[0][0] = MINE;
		myboard[2][1] = MINE;

	}

	/**
	 * Construct a new MineSweeperBoard for play at the specified level. The size of
	 * the board and the number of mines are determined by the level of play. Valid
	 * levels of play are indicated by the constants BEGINNER_LEVEL,
	 * INTERMEDIATE_LEVEL and EXPERT_LEVEL. If an invalid level of play is specified
	 * the new MineSweeperBoard should be created at the BEGINNER_LEVEL. The size of
	 * the board and the number of cells which contain mines is as follows:
	 * 
	 * <pre>
	 * &lt;U&gt;
	 * Level:              Board Size (RxC):   Mines:&lt;/U&gt;        
	 * BEGINNER_LEVEL      5x10                3
	 * INTERMEDIATE_LEVEL  10x15               15
	 * EXPERT_LEVEL        15x20               45
	 * </pre>
	 * 
	 * @param level the level of play.
	 */


	public MineSweeperBoard(int level) {
		if (level == BEGINNER_LEVEL) {
			myboard = new int[5][10];
			for (int row = 0; row < myboard.length; row++) {
				for (int col = 0; col < myboard[row].length; col++) {
					myboard[row][col] = COVERED_CELL;
				}
			}
			for (int num = 1; num <= 3; num++) {
			Random rnd = new Random();
			int x = rnd.nextInt(5);
			int y = rnd.nextInt(10);
			if(myboard[x][y]== MINE){
				num--;
			}else {
				myboard[x][y] = MINE;
			}
			}
			
		}else if (level == INTERMEDIATE_LEVEL) {
				myboard = new int[10][15];
				for (int row = 0; row < myboard.length; row++) {
					for (int col = 0; col < myboard[row].length; col++) {
						myboard[row][col] = COVERED_CELL;
					}
				}
				for (int num = 1; num <= 15; num++) {
				Random rnd = new Random();
				int x = rnd.nextInt(10);
				int y = rnd.nextInt(15);
				if(myboard[x][y]== MINE){
					num--;
				}else {
					myboard[x][y] = MINE;
				}
				}
				
		}else if (level == EXPERT_LEVEL) {
			myboard = new int[15][20];
			for (int row = 0; row < myboard.length; row++) {
				for (int col = 0; col < myboard[row].length; col++) {
					myboard[row][col] = COVERED_CELL;
				}
			}
			for (int num = 1; num <= 45; num++) {
			Random rnd = new Random();
			int x = rnd.nextInt(15);
			int y = rnd.nextInt(20);
			if(myboard[x][y]== MINE){
				num--;
			}else {
				myboard[x][y] = MINE;
			}
			}
		}
			
	}
	

	/**
	 * Get the number of rows in this MineSweeperBoard.
	 * 
	 * @return the number of rows in this MineSweeperBoard.
	 */
	public int getRows() {
		return myboard.length;

	}

	/**
	 * Get the number of columns in this MineSweeperBoard.
	 * 
	 * @return the number of columns in this MineSweeperBoard.
	 */
	public int getColumns() {

		// int num = 0;
		// for (int row = 0; row < myboard.length; row++) {
		// num = num + myboard[row].length;
		// }
		return myboard[0].length;
	}

	/**
	 * Get the number of mines in this MineSweeperBoard.
	 * 
	 * @return the number of mines in this MineSweeperBoard.
	 */
	public int getNumMines() {
		int num = 0;
		for (int row = 0; row < myboard.length; row++) {
			for (int col = 0; col < myboard[row].length; col++) {
				if (myboard[row][col] == MINE) {
					num++;
				}
			}
		}
		return num;

	}

	/**
	 * Get the current contents of the specified cell on this MineSweeperBoard.
	 * 
	 * @param row the row containing the cell.
	 * @param col the column containing the cell.
	 * @return the value contained in the cell specified by row and col, or
	 *         INVALID_CELL if the specified cell is not on the board.
	 */
	public int getCell(int row, int col) {
		if (row >= myboard.length || row < 0 || col >= myboard[row].length || col < 0) {
			return INVALID_CELL;
		} else {
			return myboard[row][col];
		}
	}

	/**
	 * Count the number of mines that appear in cells that are adjacent to the
	 * specified cell. This method returns the number of adjacent mines but does not
	 * change the contents of the board. It is a helper method for the uncoverCell
	 * method below.
	 * 
	 * @param row the row of the cell.
	 * @param col the column of the cell.
	 * @return the number of mines adjacent to the specified cell. If the specified
	 *         cell is not on the board, return 0.
	 */
	public int numAdjMines(int row, int col) {
      //int num = 0;
		//if (row > 2 || row < 0) {
			//return 0;
		//} else {
			//if (col > 3 || col < 0) {
				//return 0;
			//} else {
				//if (this.getCell(row, col - 1) == MINE) {
					//num++;
				//} else if (this.getCell(row, col + 1) == MINE) {
				//	num++;
				//} else if (this.getCell(row - 1, col) == MINE) {
					//num++;
				//} else if (this.getCell(row + 1, col) == MINE) {
				//	num++;
				//}
			//}
		//}
		//return num;
		
		int num = 0;
		if (row <= myboard.length && col <= myboard[row].length) {
			for (int indexo = row-1; indexo <= row+1; indexo++) {
				for (int indext = col-1; indext <= col+1; indext++) {
					if (getCell(indexo,indext) == MINE || getCell(indexo, indext)== FLAGGED_MINE || getCell(indexo, indext)== UNCOVERED_MINE) {
						num++;
					}
				}
				
			}
		}
		return num;

	}

	/**
	 * Uncover the specified cell. If the cell already contains a flag it should not
	 * be uncovered. If there is not a mine under the specified cell then the value
	 * in that cell is changed to the number of mines that appear in adjacent cells.
	 * If there is a mine under the specified cell then the cell is changed to the
	 * value UNCOVERED_MINE. If the specified cell is already uncovered or is not on
	 * the board, no change is made to the board.
	 * 
	 * @param row the row of the cell to be uncovered.
	 * @param col the column of the cell to be uncovered.
	 */
	public void uncoverCell(int row, int col) {

		// if (getCell(row, col) == COVERED_CELL && getCell(row, col) != FLAG) {
		// if (getCell(row, col) != MINE) {
		// myboard[row][col] = this.numAdjMines(row, col);
		// } else {
		// myboard[row][col] = UNCOVERED_MINE;
		// }
		// }
     if (row < getRows() && row >= 0 && col <getColumns() && col >= 0) {
		if (getCell(row, col) == COVERED_CELL) {
			myboard[row][col] = numAdjMines(row, col);
		} else if (getCell(row, col) == MINE) {
			myboard[row][col] = UNCOVERED_MINE;
		}
     }
	}

	/**
	 * Place or remove a flag from the specified cell. If the cell is currently
	 * covered then place a flag on the cell. If the cell currently contains a flag,
	 * remove that flag but do not uncover the cell. If the cell has already been
	 * uncovered or is not on the board, no change is made to the board.
	 * 
	 * @param row the row of the cell to be flagged/unflagged.
	 * @param col the column of the cell to be flagged/unflagged.
	 */
	public void flagCell(int row, int col) {
		// if ((getCell(row, col) == COVERED_CELL || getCell(row, col) == MINE) &&
		// getCell(row, col) != INVALID_CELL) {
   if (row < getRows() && row >= 0 && col < getColumns() && col >= 0) {
		if (getCell(row, col) == COVERED_CELL) {
			myboard[row][col] = FLAG;
		} else if (getCell(row, col) == FLAG) {
			myboard[row][col] = COVERED_CELL;
		} else if (getCell(row, col) == MINE) {
			myboard[row][col] = FLAGGED_MINE;
		} else if (getCell(row, col) == FLAGGED_MINE) {
			myboard[row][col] = MINE;
		}
     }

	}

	/**
	 * Uncover all of the cells on the board according to the criterion of the
	 * uncoverCell method.
	 */
	public void revealBoard() {
		for (int row = 0; row < myboard.length; row++) {
			for (int col = 0; col < myboard[row].length; col++) {
				this.uncoverCell(row, col);
			}
		}

	}

	/**
	 * Determine if the player has lost the current game. The game is lost if the
	 * player has uncovered a mine.
	 * 
	 * @return true if the current game has been lost and false otherwise.
	 */
	public boolean gameLost() {
		int num = 0;

		for (int row = 0; row < myboard.length; row++) {
			for (int col = 0; col < myboard[row].length; col++) {
				if (myboard[row][col] == UNCOVERED_MINE) {
					num++;
				}
			}
		}

		if (num == 0) {
			return false;
		} else {
			return true;
		}

	}

	/**
	 * Determine if the player has won the current game. The game is won when three
	 * conditions are met:
	 * <OL>
	 * <LI>Flags have been placed on all of the mines.
	 * <LI>No flags have been placed incorrectly.
	 * <LI>All non-flagged cells have been uncovered.
	 * </OL>
	 * 
	 * @return true if the current game has been won and false otherwise.
	 */
	public boolean gameWon() {
		for (int row = 0; row < myboard.length; row++) {
			for (int col = 0; col < myboard[0].length; col++) {
				if ((getCell(row, col) == MINE) || (getCell(row, col) == FLAG) || (getCell(row, col) == COVERED_CELL)) {
					return false;
				}
			}
		}
		return true;
	}
}
